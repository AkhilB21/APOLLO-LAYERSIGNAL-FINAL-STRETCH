Apollo + LayerSignal MVP Dashboard — Architecture
1. Overview
A single-page Next.js 16 dashboard that merges engine signal data (from signal_export.py) with live Google Sheet market data (RSI, SMAs, P/E, CMP) and presents it in a dark-blue themed, sortable, filterable interface with a stock detail side panel.

Design Spec Coverage: This MVP implements the Screener tab from the full 101-feature design spec — the highest-value, most-used tab. Tabs 2-7 (Scanner, Watchlist, Analytics, Alerts, Guidance, System) are deferred to Phase 2.

2. Tech Stack
Layer
Technology
Framework	Next.js 16 (App Router, 'use client')
Language	TypeScript
Styling	Tailwind CSS 4 + shadcn/ui
Icons	Lucide React
Charts	Hand-rolled SVG donut (zero extra deps)
Fonts	Geist Sans + Geist Mono (via next/font/google)
DB	Prisma (wired, not yet used in MVP)
Runtime	Bun / Node.js
Package Manager	Bun

3. Data Flow
text

┌──────────────────────┐
│  signal_export.py    │  ← Your Python engines (Apollo + LayerSignal)
│  (on your machine)   │     Outputs Apollo_Signals_Full_List.csv
└──────────┬───────────┘
           │ CSV file
           ▼
┌──────────────────────┐
│  data/               │  ← Copied to project root's data/ folder
│  Apollo_Signals_     │
│  Full_List.csv       │
└──────────┬───────────┘
           │ Read at runtime (fs.readFile)
           ▼
┌──────────────────────────────────────────────────┐
│  /api/signals (GET) — API Route                  │
│                                                   │
│  1. Read CSV from data/ folder                    │
│  2. Fetch Google Sheet CSV (live, 15s timeout)    │
│  3. Merge: engine signals + sheet market data     │
│  4. Compute summary stats                        │
│  5. Cache result for 60 seconds                   │
│  6. Return JSON                                   │
└──────────┬───────────────────────────────────────┘
           │ JSON (data[] + summary{})
           ▼
┌──────────────────────────────────────────────────┐
│  page.tsx — Client Component                      │
│                                                   │
│  ┌─────────┐  ┌──────────┐  ┌─────────────────┐  │
│  │ Stat    │  │ Donut    │  │ Filter Buttons   │  │
│  │ Cards   │  │ Chart    │  │ + Search         │  │
│  └─────────┘  └──────────┘  └─────────────────┘  │
│                                                   │
│  ┌─────────────────────────────────────────────┐  │
│  │ Sortable Table (10+ columns)                │  │
│  │ Click row → Detail Side Panel               │  │
│  └─────────────────────────────────────────────┘  │
└──────────────────────────────────────────────────┘
4. File Structure
text

my-project/
├── data/
│   └── Apollo_Signals_Full_List.csv   ← ONLY data file you replace
├── src/
│   ├── app/
│   │   ├── layout.tsx                 ← Root layout (Geist fonts, dark mode, <html class="dark">)
│   │   ├── globals.css                ← Tailwind + dark blue theme (#0B1120 palette)
│   │   ├── page.tsx                   ← MAIN DASHBOARD (all UI lives here, ~550 lines)
│   │   └── api/
│   │       ├── route.ts               ← Placeholder health check
│   │       └── signals/
│   │           └── route.ts           ← MERGE API (CSV + Google Sheet → JSON)
│   ├── components/ui/                 ← shadcn/ui library (Card, Input, Badge, etc.)
│   ├── hooks/                         ← use-mobile.ts, use-toast.ts
│   └── lib/
│       ├── db.ts                      ← Prisma client (ready for Phase 2)
│       └── utils.ts                   ← cn() helper
├── package.json
├── tailwind.config.ts
├── next.config.ts
└── prisma/
    └── schema.prisma                  ← Schema ready for Phase 2
Total custom code: 3 files (page.tsx, signals/route.ts, globals.css) — everything else is shadcn boilerplate.

5. API Endpoint: /api/signals
Request
GET /api/signals — no parameters

Response
json

{
  "data": [
    {
      "Symbol": "RELIANCE",
      "Date": "2026-08-12",
      "Apollo_Action": "HOLD",
      "Apollo_Score": 78.5,
      "Pct_Change": 1.23,
      "LayerSignal_Action": "ENTRY",
      "LayerSignal_Score": 87.2,
      "Exit_Pressure": 18.5,
      "Open": 2950.0, "High": 2980.0, "Low": 2940.0, "Close": 2975.0,
      "Volume": 4500000,
      "High52W": 3200.0, "Low52W": 2200.0,
      "RSI": 62.3,
      "20D_SMA": 2900.0, "50D_SMA": 2800.0, "200D_SMA": 2600.0,
      "PE": 28.5,
      "Stochastic": 71.0,
      "52W_Prox": 7.0,
      "CMP": 2975.0,
      "Traded_Value": 1340000000
    }
  ],
  "summary": {
    "total": 1422,
    "ENTRY": 278, "HOLD": 1148, "EXIT": 0, "FLAT": 178, "OTHER": 0,
    "avgScore": 62.4,
    "avgExitPressure": 38.7,
    "quality": { "STRONG": 45, "GOOD": 89, "MODERATE": 120, "WEAK": 24 },
    "generatedAt": "2026-08-13T01:45:59.000Z"
  }
}
Data Merge Logic
Read data/Apollo_Signals_Full_List.csv (engine output)
Fetch Google Sheet published CSV (live market data: RSI, SMAs, P/E, CMP, Traded Value, 52W High/Low)
Match on Symbol (Google Sheet's NSE: prefix stripped automatically)
Stocks in CSV but not in sheet → engine data only (RSI/SMA/PE show 0)
Stocks in sheet but not in CSV → sheet data only (signals show empty/0)
Default sort: LayerSignal_Score descending
Cache: 60 seconds server-side (avoids hammering Google Sheet on every refresh)
Google Sheet Connection
URL: Published CSV (no auth required)
Sheet columns used: Ticker, CMP, RSI, 20-Day SMA, 50-Day SMA, 200-Day SMA, PE Ratio, Stochastic Index, Proximity to 52-WH, 52-Week High, 52-Week Low, Traded Value
Timeout: 15 seconds
Failure mode: Graceful — dashboard works with engine data only
6. Frontend Components (all in page.tsx)
Component
Purpose
StatCard	6 metric cards across the top (Total, Entry, Hold, Exit, Avg Momentum, Avg Exit Pressure)
DonutChart	SVG donut showing ENTRY/HOLD/EXIT/FLAT distribution with legend
ScoreBar	Mini horizontal bar for Momentum and Exit Pressure (green/yellow/red)
SignalBadge	Color-coded pill: ENTRY (green), HOLD (yellow), EXIT (red), FLAT (grey)
QualityBadge	STRONG/GOOD/MODERATE/WEAK badge on ENTRY signals (score + exit pressure logic)
RiskBadge	LOW RISK / MEDIUM / HIGH RISK / IN TRADE label
SortIcon	▲/▼ arrow on sortable column headers
DetailPanel	Slide-in right panel with 4 metric cards, 52W position bar, all 19 data fields
DashboardPage	Main orchestrator — state, fetch, filter, sort, render

7. Business Logic
Quality Classification (ENTRY signals only)
Quality
Condition
STRONG	Score ≥ 85 AND Exit Pressure < 30
GOOD	Score ≥ 75 AND Exit Pressure < 50
MODERATE	Score ≥ 60 AND Exit Pressure < 60
WEAK	Everything else

Risk Classification
Risk
Condition
LOW RISK	ENTRY + (Score - Exit Pressure) ≥ 50
MEDIUM	ENTRY + (Score - Exit Pressure) ≥ 25
HIGH RISK	ENTRY + (Score - Exit Pressure) < 25
IN TRADE	HOLD signal

Color System
Role
Color
Hex
Bullish / Entry	Green	#3fb950
Bearish / Exit	Red	#f85149
Caution / Hold	Yellow	#d29922
Info / Apollo	Blue	#58a6ff
Apollo Brand	Purple	#a371f7
Background	Deep Navy	#0B1120
Card Background	Dark Slate	#111827
Borders	Slate	#334155

8. What This MVP Does NOT Include (Deferred to Phase 2)
Feature
Status
Scanner tab (real-time price alerts)	Phase 2
Watchlist management (add/remove/prioritize)	Phase 2
Analytics (backtest results, win rate, P&L)	Phase 2
Alerts (WebSocket push, email, sound)	Phase 2
Guidance tab (engine explanations)	Phase 2
System tab (settings, logs, health)	Phase 2
SQLite/Prisma persistence	Wired but unused — Phase 2
User authentication	Phase 2+
Mobile responsive optimization	Phase 2
Candlestick charts	Phase 2
Export to CSV/PDF	Phase 2
Auto-refresh / polling interval	Phase 2

9. To Deploy on Your Machine
Copy the entire my-project/ folder
Run bun install (or npm install)
Replace data/Apollo_Signals_Full_List.csv with fresh output from your signal_export.py
Update the GOOGLE_SHEET_URL in src/app/api/signals/route.ts if your sheet changes
Run bun run dev → opens http://localhost:3000
Only 1 file to keep updating: data/Apollo_Signals_Full_List.csv — everything else is live from Google Sheet.

That's the full architecture. Want me to paste the actual source files (page.tsx, signals/route.ts, globals.css) in chat so you can set it up on your end?