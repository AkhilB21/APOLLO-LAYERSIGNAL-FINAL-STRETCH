# New Highs & ML Confidence Tab — Implementation Audit

**Repository:** `AkhilB21/Google-AI-Sudio-Project`
**Date:** 2026-08-25
**Scope:** New Highs tab (14 frontend + 2 backend files), ML Confidence tab (9 frontend + 2 backend files), shared infrastructure
**Tech Stack:** Vite + React 19 + Express + sql.js (in-memory SQLite) + Tailwind CSS 4 — all TypeScript, zero Python

---

## Architecture Summary

This is a **full-stack** application, not just a frontend. The architecture is:

- **`server.ts`** (43KB) — Express server: fetches data from a Google Sheet CSV, parses and enriches it, serves it via REST + WebSocket
- **`server/db.ts`** — sql.js in-memory SQLite, persisted to disk via `fs.writeFileSync` after every write
- **`server/highs-service.ts`** — New Highs enrichment (proximity, exhaustion, momentum, base rates, consistency, EL confluence)
- **`server/ml-service.ts`** — ML Confidence scoring (currently a placeholder logistic function)
- **`src/`** — React 19 frontend with Vite
- **`data/Apollo_Signals_Full_List.csv`** — Static CSV fallback if Google Sheet is unreachable

### Critical Architecture Gap: Python Engine Not Integrated

The Python-based Apollo-LS Engine (5-Gate scoring, parquet pipeline, `nse_scanner.py`, XGBoost training pipeline) that we discussed in roadmaps is **NOT part of this project**. The dashboard currently:

1. Fetches a pre-scored CSV from a Google Sheet (the Apollo engine's output, scored externally)
2. Re-implements parts of the scoring logic in TypeScript inside `server.ts` and `highs-service.ts`
3. The ML tab uses a hardcoded logistic function, not the XGBoost model planned in the roadmap

This means there is **triple enrichment divergence** — scoring logic exists in:
- The Python Apollo-LS Engine (primary, external)
- `server.ts` `parseAndEnrichCsv()` (TypeScript re-implementation)
- `src/utils/enrichment.ts` `enrichStock()` (client-side re-implementation)

**Recommendation:** Once Kite Connect live feed is integrated, the Python engine should be the single source of truth for all scored data. The TypeScript server should consume the engine's output (parquet or API), not re-implement scoring. This eliminates divergence and makes the Python ML pipeline's output directly available to the dashboard.

---

## Findings by Severity

---

## CRITICAL — Will Crash or Corrupt Data

### C1. Missing null guards on nested objects crash the table

**Files:** `src/components/highs/BaseRatePanel.tsx` (line 19), `src/components/highs/ConsistencyPanel.tsx` (line 18), `src/components/highs/ExhaustionPanel.tsx` (line 80)

**Problem:** These panels destructure nested data without checking if the parent object exists. A single stock record missing `base_rates`, `consistency`, or `exhaustion_flags` will throw a `TypeError` and crash the entire table render (white screen).

**Fix — Add null guards at the top of each panel:**

```tsx
// BaseRatePanel.tsx
export const BaseRatePanel = ({ stock }: { stock: HighsStock }) => {
  if (!stock.base_rates || stock.base_rates.status === 'INSUFFICIENT_DATA') {
    return (
      <div className="px-4 py-3 text-xs text-slate-500 font-mono">
        Base rate data not yet available.
      </div>
    );
  }
  const { sample_size, win_rate, avg_return, median_return, ... } = stock.base_rates;
  // ... rest of component
};

// ConsistencyPanel.tsx
export const ConsistencyPanel = ({ stock }: { stock: HighsStock }) => {
  if (!stock.consistency) {
    return (
      <div className="px-4 py-3 text-xs text-slate-500 font-mono">
        Consistency data not yet available.
      </div>
    );
  }
  const { consistency_pct, pattern, ... } = stock.consistency;
  // ... rest of component
};

// ExhaustionPanel.tsx
// Guard the .length access
{stock.exhaustion_flags && stock.exhaustion_flags.length > 0 && (
  <div>...</div>
)}
```

---

### C2. Unbalanced parentheses in server.ts ADX calculation

**File:** `server.ts` (~line 198)

**Problem:** The `parseFloat(` wrapping the ADX fallback calculation is never closed. This is a syntax error that prevents `server.ts` from compiling.

**Fix — Add the missing closing parenthesis before `.toFixed(1)`:**

```typescript
// BEFORE (broken):
const adx = csvAdx > 0 ? csvAdx : parseFloat(Math.min(65, Math.max(12, 18 + Math.abs(pctChange) * 1.4 + Math.abs((cmp / (sma20 || 1) - 1) * 100))).toFixed(1));

// AFTER (fixed — note extra `)` before `.toFixed(1)`):
const adx = csvAdx > 0 ? csvAdx : parseFloat(Math.min(65, Math.max(12, 18 + Math.abs(pctChange) * 1.4 + Math.abs((cmp / (sma20 || 1) - 1) * 100)))).toFixed(1);
```

**How to verify:** Run `npx tsc --noEmit` or `npm run lint` — it should catch this.

---

### C3. No React error boundaries

**Files:** `src/App.tsx`, all tab components

**Problem:** No React error boundaries wrap any component. Any unhandled exception in a child component (null reference, undefined method) crashes the entire application to a white screen.

**Fix — Add an error boundary wrapper in App.tsx:**

```tsx
// src/components/ErrorBoundary.tsx
import React, { Component, ErrorInfo, ReactNode } from 'react';

interface Props { children: ReactNode; fallback?: ReactNode; }

interface State { hasError: boolean; error?: Error; }

export class ErrorBoundary extends Component<Props, State> {
  state: State = { hasError: false };

  static getDerivedStateFromError(error: Error) {
    return { hasError: true, error };
  }

  componentDidCatch(error: Error, info: ErrorInfo) {
    console.error('ErrorBoundary caught:', error, info.componentStack);
  }

  render() {
    if (this.state.hasError) {
      return this.props.fallback || (
        <div className="flex items-center justify-center h-64 text-slate-400 text-sm">
          <p>Something went wrong rendering this section. Check the console.</p>
        </div>
      );
    }
    return this.props.children;
  }
}
```

Then wrap each tab in App.tsx:

```tsx
{activeTab === 'new_highs' && (
  <ErrorBoundary>
    <NewHighsTab ... />
  </ErrorBoundary>
)}
{activeTab === 'ml_confidence' && (
  <ErrorBoundary>
    <MLConfidenceTab />
  </ErrorBoundary>
)}
```

---

### C4. ML `Sector` field contains MCap label, not actual sector

**File:** `server/ml-service.ts` (line 277)

**Problem:**
```typescript
Sector: stock.MCap ? `${stock.MCap} Cap` : 'Equities',
```
This maps "Large" → "Large Cap", "Mid" → "Mid Cap". The table column labeled "Sector" shows market cap categories. The search-by-sector filter in `MLConfidenceTable.tsx` is therefore broken — searching for "IT" or "Bank" returns nothing.

**Fix — Use actual sector data:**

```typescript
// In server/ml-service.ts extractFeatures() or scoreStock()
Sector: stock.Sector || stock.SECTOR || (stock.MCap ? `${stock.MCap} Cap` : 'Equities'),
```

Also verify that the source CSV/Google Sheet has a `Sector` or `Industry` column. If not, add the sector lookup map from `highs-service.ts` `SECTOR_LOOKUP` into the ML service as well.

---

## HIGH — Incorrect Behavior

---

### H1. ATH view mode doesn't recalculate proximity tier

**File:** `server/highs-routes.ts` (lines 124-131)

**Problem:** When `viewMode === 'ath'`, `proximity_pct` is replaced with `ath_cmp_pct` and `distance_pct` is recalculated, but `proximity_tier` is NOT recalculated. A stock can be "AT" its 52-week high but "FAR" from its all-time high, yet it still displays the "BREAKOUT" (AT) tier badge.

**Fix — Recalculate tier after replacing proximity in ATH mode:**

```typescript
// In server/highs-routes.ts, after the ATH proximity replacement block:
if (viewMode === 'ath') {
  for (const s of enriched.stocks) {
    s.proximity_pct = s.ath_cmp_pct;
    s.distance_pct = parseFloat((((s.all_time_high - s.CMP) / s.all_time_high) * 100).toFixed(2));
    // ADD THIS: recalculate tier based on ATH proximity
    const { tier } = computeProximityTier(s.CMP, s.all_time_high);
    s.proximity_tier = tier;
  }
}
```

---

### H2. Base rates are deterministic formulas, not empirical data

**File:** `server/highs-service.ts` `computeBaseRates()` (lines 422-490)

**Problem:** The function starts from hardcoded base values (win rate 54%, avg return 3.2%, sample size 35) and applies additive adjustments based on tier, score, gates, and momentum. The `sample_size` is arithmetically constructed, not a count of actual historical occurrences. The distribution breakdown is derived from percentages, not from real outcome data.

**Current state:** This is acceptable as a **placeholder** until real backtested base rates are available from the Python engine's parquet data.

**Fix when Python engine is integrated:**
1. Pre-compute base rates from actual historical parquet data (group by tier × apollo_range × gate_count × momentum_profile)
2. Store the aggregated statistics in a SQLite table or JSON file
3. Replace `computeBaseRates()` with a lookup function that queries real data
4. If sample size for a specific cohort is < 30, display "Insufficient data" instead of fabricated numbers

---

### H3. Consistency and momentum use synthetic/fake data

**Files:** `server/highs-service.ts` `computeRateOfApproach()` (lines 178-235), `computeConsistencyScore()` (lines 492-535)

**Problem:** Both functions operate on the 10-point sparkline array (if available) or generate **fake 20-day close data** using a deterministic formula when the sparkline is absent. The formula on lines 197-204 (`let prev = cmp * (1 - (pctChange / 100) * 0.05)`) produces synthetic prices that don't reflect actual market behavior.

**Fix when Kite Connect is integrated:**
1. Fetch actual daily OHLCV history (at least 60 trading days) from Kite Connect
2. Replace sparkline-based computation with actual close-to-close returns
3. Pass the real close history array into these functions instead of deriving from a 10-point sparkline

---

### H4. ML model card shows fake metrics with no "unavailable" state

**File:** `src/components/ml/MLModelCard.tsx` (lines 18-24)

**Problem:** When `modelInfo` is null (API failure or model not loaded), every metric falls back to hardcoded defaults (AUC 0.648, 115,200 train samples, 18 features). The user cannot distinguish between real loaded data and fabricated fallbacks. The card also unconditionally shows "Purged Split & Embargo Active" regardless of model state.

**Fix — Add a distinct unavailable state:**

```tsx
export const MLModelCard = ({ modelInfo }: { modelInfo: MLModelInfo | null }) => {
  const isUsingDefaults = !modelInfo;

  if (isUsingDefaults) {
    return (
      <div className="bg-slate-900/50 border border-amber-500/30 rounded-lg p-4">
        <div className="flex items-center gap-2 text-amber-400 text-xs font-mono mb-2">
          <AlertTriangle className="w-4 h-4" />
          Model Not Loaded — Showing Estimated Defaults
        </div>
        <p className="text-xs text-slate-400">
          Train the XGBoost meta-learner to see real model metrics.
        </p>
      </div>
    );
  }

  // Rest of component uses real modelInfo data
};
```

---

### H5. Trade sizing target has no relationship to model's expected return

**File:** `src/components/ml/MLTradeSizingPanel.tsx` (line 12)

**Problem:** Target price is `CMP * (1 + stop_loss_pct * 2.8)`. The R:R ratio is a hardcoded string `'1 : 3.2'`. Neither is derived from the model's `ml_expected_20d_return`. A stock with +5% expected return might show an +18% target.

**Fix — Derive target from expected return:**

```typescript
const expectedReturn = stock.ml_expected_20d_return; // e.g. 5.2
const targetPrice = cmp * (1 + Math.max(expectedReturn, 1.5) / 100); // Use model's expectation
const actualRR = suggestedStopLoss > 0
  ? ((targetPrice - cmp) / (cmp * suggestedStopLoss / 100)).toFixed(1)
  : 'N/A';
```

---

### H6. ML Confidence badge tooltip hardcodes "20 days"

**File:** `src/components/ml/MLConfidenceBadge.tsx` (line 78)

**Problem:** The tooltip always says "probability of +5% gain in 20 days" even when displaying 5D or 10D confidence.

**Fix — Accept a `horizon` prop:**

```tsx
interface Props {
  confidence: number;
  size?: 'sm' | 'md' | 'lg';
  horizon?: '5d' | '10d' | '20d'; // ADD THIS
}

const HORIZON_LABELS = {
  '5d': { gain: '2%', days: '5' },
  '10d': { gain: '3%', days: '10' },
  '20d': { gain: '5%', days: '20' },
};

// In tooltip:
`Probability of +${HORIZON_LABELS[horizon].gain} gain in ${HORIZON_LABELS[horizon].days} days`
```

Then pass `horizon` from `MLTableRow.tsx` when rendering the badge for each column.

---

### H7. Sort doesn't reset page in ML table

**File:** `src/components/ml/MLConfidenceTable.tsx` `handleSort()`

**Problem:** Changing sort order while on page 5 keeps the page at 5, potentially showing an empty page.

**Fix:**

```typescript
const handleSort = (field: string) => {
  setSortBy(field);
  setSortDir(prev => sortBy === field ? (prev === 'asc' ? 'desc' : 'asc') : 'desc');
  setPage(1); // ADD THIS
};
```

---

### H8. Hidden interaction term not tracked in ML contributions

**File:** `server/ml-service.ts` (lines 238-240)

**Problem:** The "Dual Engine Synergy" bonus (+0.28 logit points) is added to the total logit but NOT pushed to the `contributions` array. The factor waterfall in the UI won't sum to the final probability — there's a hidden +0.28 invisible to the user.

**Fix — Push the interaction term as a contribution:**

```typescript
if (apolloScore >= 80 && ['EL1', 'EL2'].includes(elStatus)) {
  logit += 0.28;
  contributions.push({
    feature: 'dual_engine_synergy',
    label: 'Dual Engine Synergy',
    value: 'Apollo ≥ 80 + EL1/EL2',
    impact: 0.28,
    category: 'ENGINE'
  });
}
```

---

## MEDIUM — Performance, Security, Robustness

---

### M1. `enrichHighsUniverse()` called 3x on page load

**File:** `server/highs-routes.ts`

**Problem:** The `/api/highs/breadth`, `/api/highs/sectors`, and `/api/highs/stocks` endpoints each independently call `enrichHighsUniverse()` which runs the full P0-P3 enrichment pipeline. On page load, the frontend may hit all three simultaneously.

**Fix — Cache the enrichment result per request cycle:**

```typescript
let enrichmentCache: { timestamp: number; result: ReturnType<typeof enrichHighsUniverse> } | null = null;
const CACHE_TTL = 5000; // 5 seconds

function getEnrichedData(stocks: RawStockInput[], db: Database) {
  const now = Date.now();
  if (enrichmentCache && now - enrichmentCache.timestamp < CACHE_TTL) {
    return enrichmentCache.result;
  }
  const result = enrichHighsUniverse(stocks, db);
  enrichmentCache = { timestamp: now, result };
  return result;
}
```

---

### M2. No server-side pagination for ML stocks

**File:** `server/ml-routes.ts`

**Problem:** `/api/ml/stocks` returns ALL filtered stocks at once. Each stock includes a `contributions` array (~8 items × ~100 bytes) and a `trade_sizing` object. For 500 stocks this creates a ~500KB+ response.

**Fix — Add `page` and `page_size` query parameters:**

```typescript
const page = Math.max(1, parseInt((req.query.page as string) || '1', 10));
const pageSize = Math.max(1, Math.min(200, parseInt((req.query.page_size as string) || '100', 10)));
const offset = (page - 1) * pageSize;

// After filtering and sorting:
const paginatedStocks = filteredStocks.slice(offset, offset + pageSize);

res.json({
  data: paginatedStocks,
  total: filteredStocks.length,
  page,
  page_size: pageSize,
  summary: summary
});
```

---

### M3. Synchronous DB writes block the event loop

**File:** `server/db.ts` — `saveDb()` uses `fs.writeFileSync`

**Problem:** Every POST/PATCH/DELETE endpoint calls `saveDb()`, which writes the entire SQLite database to disk synchronously. Under concurrent requests, this blocks the Node.js event loop, degrading response times and WebSocket latency.

**Fix — Convert to async writes with debouncing:**

```typescript
let saveTimeout: NodeJS.Timeout | null = null;

export async function saveDb() {
  if (saveTimeout) clearTimeout(saveTimeout);
  saveTimeout = setTimeout(() => {
  const data = db.export();
  const buffer = Buffer.from(data);
  fs.promises.writeFile(DB_PATH, buffer);
  }, 500); // Debounce: write at most once per 500ms
}
```

---

### M4. No input validation on query parameters

**Files:** `server/highs-routes.ts`, `server/ml-routes.ts`

**Problem:** Query parameters are cast with `as string` and used without validation. `req.query.search` could be `string[]` (multi-value). `limit` and `offset` are not clamped. `sortBy` could be any string.

**Fix — Add a validation helper:**

```typescript
function getStringParam(query: any, key: string, fallback: string = ''): string {
  const val = query[key];
  if (Array.isArray(val)) return val[0] || fallback;
  if (typeof val === 'string') return val;
  return fallback;
}

function getIntParam(query: any, key: string, min: number, max: number, fallback: number): number {
  const parsed = parseInt(getStringParam(query, key, String(fallback)), 10);
  if (isNaN(parsed)) return fallback;
  return Math.max(min, Math.min(max, parsed));
}

// Usage:
const search = getStringParam(req.query, 'search');
const limit = getIntParam(req.query, 'limit', 1, 500, 100);
const sortBy = getStringParam(req.query, 'sort_by', 'proximity_pct');
```

---

### M5. SQL string interpolation in ML routes

**File:** `server/ml-routes.ts` (lines 160-164)

**Problem:**
```typescript
db.exec(`
  UPDATE ml_model_metadata
  SET last_calibration = '${newTrainDate}',
  calibration_status = 'HEALTHY'
  WHERE id = 'xgboost_20d_v1'
`);
```
While `newTrainDate` is currently safe (`new Date().toISOString()`), this template literal pattern is dangerous if copied elsewhere with user input.

**Fix — Use parameterized queries:**

```typescript
const stmt = db.prepare(`
  UPDATE ml_model_metadata
  SET last_calibration = ?, calibration_status = 'HEALTHY'
  WHERE id = 'xgboost_20d_v1'
`);
stmt.run([newTrainDate]);
stmt.free();
```

---

### M6. Race condition on rapid filter changes in ML tab

**File:** `src/components/tabs/MLConfidenceTab.tsx`

**Problem:** No `AbortController` on fetches. Rapidly toggling horizon/preset/tier triggers multiple in-flight requests; the last to arrive wins, which may not match the current UI state.

**Fix:**

```typescript
const fetchData = useCallback(async () => {
  const controller = new AbortController();
  // Store controller ref to abort on next call
  abortRef.current = controller;

  setIsLoading(true);
  setError(null);

  try {
    const res = await fetch(`/api/ml/stocks?...`, { signal: controller.signal });
    if (!res.ok) throw new Error(`HTTP ${res.status}`);
    const json = await res.json();
    if (!controller.signal.aborted) {
      setStocks(json.data || []);
      setSummary(json.summary || null);
    }
  } catch (err: any) {
    if (err.name !== 'AbortError' && !abortRef.current?.signal.aborted) {
      setError(err.message);
    }
  } finally {
    if (!controller.signal.aborted) {
      setIsLoading(false);
    }
  }
}, [horizon, preset, tier]);
```

---

### M7. No `React.memo` on table rows

**Files:** `src/components/highs/HighsTableRow.tsx`, `src/components/ml/MLTableRow.tsx`

**Problem:** Every parent re-render re-renders all table rows. For 100+ stocks, this causes noticeable lag when filters or sort change.

**Fix:**

```typescript
// At the bottom of each file, change the export:
export const HighsTableRow = React.memo(HighsTableRowInner);

// Or wrap the component:
const HighsTableRowInner = ({ stock, ... }: Props) => { ... };
export const HighsTableRow = React.memo(HighsTableRowInner);
```

---

### M8. `mark-read` endpoint marks ALL alerts as read

**File:** `server.ts` (~line 1082)

**Problem:** `db.exec("UPDATE alert_logs SET read = 1")` has no WHERE clause. A single request marks every alert in the database as read.

**Fix:**

```typescript
// Option A: Mark all (current behavior, but intentional):
app.post('/api/db/alerts/mark-read', (req, res) => {
  try {
    db.exec("UPDATE alert_logs SET read = 1 WHERE read = 0");
    res.json({ marked: db.getRowsModified() });
  } catch (err) { ... }
});

// Option B: Mark specific alerts by ID (more useful):
app.post('/api/db/alerts/mark-read', (req, res) => {
  const { ids } = req.body; // expect array of alert IDs
  if (!Array.isArray(ids)) return res.status(400).json({ error: 'ids array required' });
  const placeholders = ids.map(() => '?').join(',');
  db.exec(`UPDATE alert_logs SET read = 1 WHERE id IN (${placeholders})`, ids);
  res.json({ marked: ids.length });
});
```

---

### M9. `getCol` in ML service has falsy-value bug

**File:** `server/ml-service.ts` (lines 533-554)

**Problem:**
```typescript
const getCol = (name: string) => v[cols.indexOf(name)];
// Later: getCol('train_auc') || 0.648
```
If the actual value is `0` or `''` (empty string), the `||` operator treats it as falsy and falls back to the default. This means a real AUC of `0` would be replaced with `0.648`.

**Fix — Use nullish coalescing:**

```typescript
const getCol = (name: string) => {
  const idx = cols.indexOf(name);
  return idx >= 0 ? v[idx] : undefined;
};
// Usage: getCol('train_auc') ?? 0.648
```

---

## LOW — UX, Polish, Accessibility

---

### L1. Search input not debounced (New Highs)

**File:** `src/components/highs/HighsFilters.tsx` (line 59)

**Fix:**

```typescript
const [localSearch, setLocalSearch] = useState(filters.search);

useEffect(() => {
  const timer = setTimeout(() => {
    onChangeFilter('search', localSearch);
  }, 300);
  return () => clearTimeout(timer);
}, [localSearch]);

// In JSX:
<input value={localSearch} onChange={e => setLocalSearch(e.target.value)} ... />
```

---

### L2. Invalid Tailwind class `bg-slate-850`

**Files:** `src/components/highs/HighsTableRow.tsx` (line 299), `src/components/highs/ViewToggle.tsx` (line 45)

**Fix:** Replace `bg-slate-850` with `bg-slate-800` or `bg-slate-900`.

---

### L3. Missing keyboard accessibility on interactive elements

**Files:** `src/components/highs/HighsTable.tsx` (sortable `<th>`), `src/components/highs/ViewToggle.tsx` (tab buttons), `src/components/ml/MLFeatureImportanceModal.tsx` (no Escape-to-close)

**Fix:**
- Sortable `<th>`: Add `tabIndex={0}` and `onKeyDown={(e) => e.key === 'Enter' && handleSort(id)}`
- ViewToggle: Add `role="tablist"` on container, `role="tab" aria-selected` on each button
- Modal: Add `useEffect` with `keydown` listener for Escape, add `onClick` on backdrop for click-outside-to-close

---

### L4. Inconsistent number formatting

**Files:** `WatchlistAlertBanner.tsx` vs `HighsTableRow.tsx`

**Fix:** Standardize on `toLocaleString('en-IN', { minimumFractionDigits: 2, maximumFractionDigits: 2 })` everywhere.

---

### L5. Unused imports across 10+ files

**Files:** Nearly every component file

**Fix:** Run `npx tsc --noEmit` which will flag unused imports. Or configure `noUnusedLocals: true` in `tsconfig.json`.

---

### L6. Tier summary cards show zeros when data hasn't loaded

**File:** `src/components/highs/TierSummaryCards.tsx`

**Fix:** When `summary` is null, show a skeleton loader (4 pulsing boxes) instead of real cards with zero counts.

---

### L7. ML table CSV export doesn't escape fields

**File:** `src/components/ml/MLConfidenceTable.tsx` (lines 96-118)

**Fix:**

```typescript
const escapeCsv = (val: any) => {
  const str = String(val ?? '');
  if (str.includes(',') || str.includes('"') || str.includes('\n')) {
    return `"${str.replace(/"/g, '""')}"`;
  }
  return str;
};

// Use: rows.map(e => e.map(escapeCsv).join(','))
// Add BOM for Excel: '\uFEFF' + content
```

---

### L8. Gate rendering fakes data when Gates array is missing

**File:** `src/components/highs/HighsTableRow.tsx` (line 337)

**Problem:** `const passed = Gates ? Gates[idx] : idx < gate_count;` — if Gates is null/undefined, it assumes the first N gates passed. This silently masks missing data.

**Fix:**

```typescript
const passed = Gates ? Gates[idx] : null; // null = unknown
// In rendering:
{passed === true ? (
  <CheckCircle2 className="w-3.5 h-3.5 text-emerald-400" />
) : passed === false ? (
  <XCircle className="w-3.5 h-3.5 text-slate-600" />
) : (
  <span className="w-3.5 h-3.5 text-slate-600">—</span>
)}
```

---

### L9. BreadthBar regime lookup can return undefined

**File:** `src/components/highs/BreadthBar.tsx` (line 52)

**Fix:** Add a fallback after the object lookup:

```typescript
const regimeConfig = (REGIME_CONFIG as any)[regime] || {
  label: 'DATA UNAVAILABLE', color: '#94a3b8', bg: 'rgba(148,163,184,0.12)', border: 'rgba(148,163,184,0.3)'
};
```

---

### L10. NH-NL ratio misleading when new_lows is 0

**File:** `src/components/highs/BreadthBar.tsx` (line 122)

**Problem:** `(new_highs / (new_lows || 1))` — when there are 0 new lows, it shows e.g. "200.0x" instead of indicating infinity/no comparison.

**Fix:**

```typescript
const ratioStr = new_lows === 0
  ? `${new_highs}:0`
  : `${(new_highs / new_lows).toFixed(1)}:1`;
```

---

### L11. Allocation labels in trade sizing have gaps

**File:** `src/components/ml/MLTradeSizingPanel.tsx` (lines 38-44)

**Problem:** Only `125`, `100`, and `60` are checked. Any other value (80, 150, 0) falls through to "Zero Exposure".

**Fix:**

```typescript
let allocationLabel: string;
if (sizing.recommended_allocation_pct >= 120) allocationLabel = 'OVERWEIGHT';
else if (sizing.recommended_allocation_pct >= 80) allocationLabel = 'STANDARD';
else if (sizing.recommended_allocation_pct >= 40) allocationLabel = 'CAUTIOUS';
else allocationLabel = 'ZERO EXPOSURE';
```

---

### L12. Hardcoded P0/P1/P2 labels in TabBar visible to end users

**File:** `src/components/shell/TabBar.tsx` (lines 53-63)

**Fix:** Remove the priority badge or replace with user-friendly labels (e.g., "Core", "Analysis", "System").

---

### L13. SectorClusters silently limits to 8 clusters

**File:** `src/components/highs/SectorClusters.tsx` (line 39)

**Fix:** Add a "+N more clusters" indicator when `clusters.length > 8`.

---

### L14. Mock data conflicts with DB-seeded data

**Files:** `src/data/mockData.ts`, `server/db.ts`

**Problem:** `mockData.ts` has 6 trade records. `db.ts` seeds 20 trade records. Both may be used simultaneously depending on code path.

**Fix:** Remove `INITIAL_TRADES` and `INITIAL_INDICES` from `mockData.ts` once the DB endpoints are confirmed working. Keep only as dev-only fallbacks behind a feature flag.

---

## Implementation Priority for the Implementor

### Phase 1 — Must Fix Before Any Use (Crash Prevention)
| ID | Fix | Estimated Time |
|----|-----|----------------|
| C1 | Add null guards to BaseRatePanel, ConsistencyPanel, ExhaustionPanel | 15 min |
| C2 | Fix parentheses in server.ts ADX line | 2 min |
| C3 | Add ErrorBoundary wrapper in App.tsx | 20 min |
| C4 | Fix ML Sector field to use actual sector data | 10 min |

### Phase 2 — Should Fix Before Production (Correctness)
| ID | Fix | Estimated Time |
|----|-----|----------------|
| H1 | Recalculate proximity tier in ATH mode | 10 min |
| H5 | Derive trade sizing target from model expected return | 15 min |
| H6 | Add horizon prop to MLConfidenceBadge | 15 min |
| H7 | Reset page on sort change in ML table | 2 min |
| H8 | Track Dual Engine Synergy in contributions array | 10 min |
| H4 | Add unavailable state to MLModelCard | 20 min |
| M9 | Fix getCol falsy-value bug with ?? | 5 min |

### Phase 3 — Should Fix Before Scaling (Performance & Security)
| ID | Fix | Estimated Time |
|----|-----|----------------|
| M1 | Cache enrichment result in highs routes | 30 min |
| M2 | Add server-side pagination for ML stocks | 30 min |
| M3 | Convert saveDb to async with debouncing | 20 min |
| M4 | Add input validation helper for query params | 20 min |
| M5 | Convert SQL interpolation to parameterized queries | 10 min |
| M6 | Add AbortController to ML tab fetches | 20 min |
| M7 | Add React.memo to table row components | 10 min |
| M8 | Fix mark-read endpoint | 10 min |

### Phase 4 — Polish (UX & Accessibility)
| ID | Fix | Estimated Time |
|----|-----|----------------|
| L1 | Debounce search input | 10 min |
| L2 | Fix invalid Tailwind class | 2 min |
| L3 | Add keyboard accessibility | 30 min |
| L4 | Standardize number formatting | 15 min |
| L5 | Remove unused imports | 10 min |
| L6 | Add loading skeletons | 20 min |
| L7 | Fix CSV export escaping | 10 min |
| L8 | Fix gate rendering for missing data | 10 min |
| L9-L14 | Remaining low-priority fixes | 30 min |

### Phase 5 — When Python Engine is Integrated
| ID | Fix | Estimated Time |
|----|-----|----------------|
| H2 | Replace base rates with real backtested data | 2-4 hours |
| H3 | Replace synthetic consistency/momentum with real OHLCV | 1-2 hours |
| Architecture | Eliminate triple enrichment — single source of truth from Python engine | 4-8 hours |
| Architecture | Swap ML placeholder for real XGBoost model pipeline | Per ML roadmap |
