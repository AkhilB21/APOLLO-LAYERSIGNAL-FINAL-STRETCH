"""Apollo-LS Core Computation Kernel."""
