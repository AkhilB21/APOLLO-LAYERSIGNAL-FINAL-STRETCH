"""Apollo Core — Type Definitions.
Dataclasses shared across calculation engines and orchestration services.
"""

from __future__ import annotations
from dataclasses import dataclass, field
from typing import Optional, Any


@dataclass
class TradeEvent:
    """A single completed round-trip trade (entry -> exit)."""
    symbol: str
    entry_date: str
    entry_price: float
    exit_date: str
    exit_price: float
    direction: str                    # "LONG" (or future "SHORT")
    exit_reason: str                  # e.g. "SL Hit", "Target Hit", "RSI Divergence"
    quantity: float = 1.0
    pnl: float = 0.0                  # absolute P&L
    pnl_pct: float = 0.0              # percentage P&L
    holding_days: int = 0
    raw_score: float = 0.0            # entry score
    bucket: str = ""                  # bucket label at entry
    bucket_multiplier: float = 1.0    # multiplier at entry (recorded, not applied in V3.3+)
    ignored_exits: list = field(default_factory=list)  # exits user ignored in live mode


@dataclass
class DailyResult:
    """Per-day signal evaluation result for one stock."""
    date: str
    symbol: str
    raw_score: float
    total_score: float                # = raw_score (bucket decoupled in V3.3+)
    bucket: str = ""
    bucket_multiplier: float = 1.0
    entry_signal: bool = False        # score >= ENTRY_THRESHOLD
    trough_pos: str = ""              # e.g. "0 / 5"
    signals_hit: list = field(default_factory=list)  # which of the 21 signals fired
    ipo_signals_hit: list = field(default_factory=list)


@dataclass
class SignalResult:
    """Result of evaluating all 21 (+ 12 IPO) signals for one bar."""
    date: str
    symbol: str
    raw_total: float                  # sum of all signal weights
    signal_details: dict = field(default_factory=dict)   # {signal_name: weight or 0}
    ipo_raw_total: float = 0.0
    ipo_signal_details: dict = field(default_factory=dict)
    is_ipo_period: bool = False
    weekly_rsi: float = 0.0
    adx: float = 0.0
    atr: float = 0.0
    rsi: float = 0.0


@dataclass
class Position:
    """Mutable position state for a single stock's trade lifecycle."""
    in_trade: bool = False
    entry_price: Optional[float] = None
    entry_date: Any = None              # pd.Timestamp or datetime
    peak_rsi: Optional[float] = None
    peak_rsi_price: Optional[float] = None
    peak_rsi_date: Any = None
    peak_close: Optional[float] = None
    trail_activation_price: Optional[float] = None   # DUAL_SL only
    prev_plus_di: Optional[float] = None
    prev_minus_di: Optional[float] = None
    prev_macd: Optional[float] = None
    prev_macd_sig: Optional[float] = None
    icu_active: bool = False                         # True if Score < 45
    pending_exit: bool = False                       # True after EXIT alert, before user confirm
    pending_exit_payload: Optional[dict] = None      # saved ExitDecision payload for dashboard
    dynamic_sl_pct: Optional[float] = None           # Dynamic stop loss multiplier set at entry


@dataclass
class ExitConfig:
    """Immutable configuration for exit detection."""
    exit_mode: str = "FIXED_SL"
    sl_percent: float = 5.0
    trailing_sl_percent: float = 3.0
    trailing_activate_pct: float = 5.0
    divergence_rsi_drop: float = 3.0
    exit_threshold: float = 50.0
    entry_threshold: float = 70.0
    indicator_exit: str = ""

    @property
    def hard_sl_mult(self) -> float:
        return 1.0 - self.sl_percent / 100.0 if self.sl_percent > 0 else 0.0

    @property
    def trail_sl_mult(self) -> float:
        return (1.0 - self.trailing_sl_percent / 100.0
                if self.trailing_sl_percent > 0 else 0.0)


@dataclass
class ExitDecision:
    """Output of detect_exit_triggers()."""
    should_exit: bool = False
    fill_price: Optional[float] = None
    primary_reason: Optional[str] = None
    primary_class: Optional[str] = None
    all_triggered_reasons: list = field(default_factory=list)
    hard_sl_hit: bool = False
    trail_sl_hit: bool = False
    div_hit: bool = False
    di_hit: bool = False
    score_hit: bool = False
    indicator_hit: bool = False
