"""Two-Layer Bucket Classifier for Apollo Backtest Engine (v5.0).

Absolute Structural Bucketing replacing the legacy 200-DMA cascade rules.
This guarantees every stock is classified cleanly and dynamically plugs directly 
into Apollo's Entry Threshold gating.

Buckets:
1. Trending Up (Prime) -> Entry Threshold = 60
2. Recovery (Value) -> Entry Threshold = 70
3. Sideways / Basing (Wait) -> Entry Threshold = 80
4. Structural Decline (Avoid) -> Hard Block

Functions
---------
  compute_bucket_metrics    — compute required metrics (MAs, highs, etc.)
  classify_stock_bucket     — classify a stock for display (last bar)
  pre_filter_bucket         — deprecated alias
  classify_bucket           — classify a single bar into a bucket (Layer 2)
  get_score_multiplier      — legacy multiplier (now engine uses dynamic thresholds)
"""

from __future__ import annotations

import numpy as np
import pandas as pd

# =========================================================================
# Constants
# =========================================================================

BUCKET_ORDER = [
    "Trending Up - Tier 1 (PRIME)",
    "Trending Up - Tier 2 (CONFIRMED)",
    "Trending Up - Tier 3 (EMERGING)",
    "Trending Up - Tier 4 (WATCH)",
    "Recovery",
    "Sideways / Basing",
    "Structural Decline",
    "IPO / New Listing",
]

# Legacy multiplier map (Engine now uses dynamic thresholds instead)
SCORE_MULTIPLIERS = {
    "Trending Up - Tier 1 (PRIME)":     1.0,
    "Trending Up - Tier 2 (CONFIRMED)": 1.0,
    "Trending Up - Tier 3 (EMERGING)":  1.0,
    "Trending Up - Tier 4 (WATCH)":     1.0,
    "Recovery":                         1.0,
    "Sideways / Basing":                1.0,
    "Structural Decline":               0.0,
    "IPO / New Listing":                1.0,
}

SKIP_BUCKETS = {"Structural Decline"}

# Colour coding for UI display
BUCKET_COLOURS = {
    "Trending Up - Tier 1 (PRIME)":     "#16a34a", # Dark Green
    "Trending Up - Tier 2 (CONFIRMED)": "#22c55e", # Green
    "Trending Up - Tier 3 (EMERGING)":  "#4ade80", # Light Green
    "Trending Up - Tier 4 (WATCH)":     "#86efac", # Pale Green
    "Recovery":                         "#3b82f6", # Blue
    "Sideways / Basing":                "#f59e0b", # Amber
    "Structural Decline":               "#ef4444", # Red
    "IPO / New Listing":                "#06b6d4", # Cyan
}

# Short descriptions for UI tooltips
BUCKET_DESC = {
    "Trending Up - Tier 1 (PRIME)":     "Rocketship. Near ATH with expanding momentum (ADX > 25).",
    "Trending Up - Tier 2 (CONFIRMED)": "Established uptrend. MA stack perfectly aligned.",
    "Trending Up - Tier 3 (EMERGING)":  "Recent breakout. Trend started but MA stack still fanning out.",
    "Trending Up - Tier 4 (WATCH)":     "Technically trending, but momentum is fading (ADX < 20).",
    "Recovery":                         "Golden Cross or early structural reversal from lows.",
    "Sideways / Basing":                "Volatility contraction or weak trend. Strict entry rules.",
    "Structural Decline":               "Trapped below 50 & 200 DMA, down >30%. Blocked.",
    "IPO / New Listing":                "Insufficient history. Uses dedicated IPO profile.",
}

BUCKET_APOLLO_FIT = {
    "Trending Up - Tier 1 (PRIME)":     "Primary Target (Tier 1)",
    "Trending Up - Tier 2 (CONFIRMED)": "Primary Target (Tier 2)",
    "Trending Up - Tier 3 (EMERGING)":  "Primary Target (Tier 3)",
    "Trending Up - Tier 4 (WATCH)":     "Primary Target (Tier 4)",
    "Recovery":                         "Primary Target (Standard)",
    "Sideways / Basing":                "Secondary (Strict Entry)",
    "Structural Decline":               "Avoid",
    "IPO / New Listing":                "IPO Profile",
}

# Bundle all metadata into a single dict for easy import
BUCKET_DEFS = {
    name: {
        "colour": BUCKET_COLOURS.get(name, "#6b7280"),
        "multiplier": SCORE_MULTIPLIERS.get(name, 1.0),
        "apollo_fit": BUCKET_APOLLO_FIT.get(name, "Review"),
        "description": BUCKET_DESC.get(name, ""),
    }
    for name in BUCKET_ORDER
}

# =========================================================================
# Metric Computation
# =========================================================================

def compute_rsi(series: pd.Series, period: int) -> pd.Series:
    """Wilder's RSI."""
    delta = series.diff()
    gain = (delta.where(delta > 0, 0)).ewm(alpha=1/period, adjust=False).mean()
    loss = (-delta.where(delta < 0, 0)).ewm(alpha=1/period, adjust=False).mean()
    rs = gain / loss
    return 100 - (100 / (1 + rs))

def compute_bucket_metrics(df_d: pd.DataFrame, df_w: pd.DataFrame = None) -> dict[str, pd.Series]:
    """Compute primary bucket classification metrics from daily data."""
    close = df_d["close"]
    high = df_d.get("high", close)
    low = df_d.get("low", close)
    
    dma200 = close.rolling(window=200, min_periods=100).mean()
    dma50 = close.rolling(window=50, min_periods=50).mean()
    ema21 = close.ewm(span=21, adjust=False).mean()
    
    high52w = high.rolling(window=252, min_periods=60).max()
    dist_from_high = (close - high52w) / high52w * 100.0

    # Trend Strength
    dma50_slope = dma50.diff(20) / 20.0
    dma50_slope_pct = (dma50 - dma50.shift(20)) / dma50.shift(20) * 100.0
    price_vs_50dma_pct = (close - dma50) / dma50 * 100.0
    price_vs_200dma_pct = (close - dma200) / dma200 * 100.0
    
    # ADX - use pre-computed if available, else nan
    adx = df_d["adx"] if "adx" in df_d.columns else pd.Series(np.nan, index=df_d.index)
    
    # Momentum: MACD Hist and Stoch %K
    ema12 = close.ewm(span=12, adjust=False).mean()
    ema26 = close.ewm(span=26, adjust=False).mean()
    macd_line = ema12 - ema26
    macd_signal = macd_line.ewm(span=9, adjust=False).mean()
    macd_hist = macd_line - macd_signal
    
    highest_high_14 = high.rolling(14).max()
    lowest_low_14 = low.rolling(14).min()
    stoch_k = (close - lowest_low_14) / (highest_high_14 - lowest_low_14) * 100.0
    
    # RSIs
    rsi21 = compute_rsi(close, 21)
    rsi36 = compute_rsi(close, 36)
    rsi56 = compute_rsi(close, 56)
    
    # Weekly EMA10 Alignment & Weekly RSIs
    weekly_ema10 = pd.Series(np.nan, index=df_d.index)
    rsi21_w = pd.Series(np.nan, index=df_d.index)
    rsi36_w = pd.Series(np.nan, index=df_d.index)
    rsi56_w = pd.Series(np.nan, index=df_d.index)
    
    if df_w is not None and not df_w.empty and "close" in df_w.columns:
        w_close = df_w["close"]
    else:
        # Resample from daily on the fly if df_w is not provided
        if isinstance(df_d.index, (pd.DatetimeIndex, pd.PeriodIndex)):
            w_df = df_d.resample('W-FRI').agg({'close': 'last'})
            w_close = w_df['close'].dropna()
        elif "date" in df_d.columns:
            w_df = df_d.set_index(pd.to_datetime(df_d["date"], errors="coerce")).resample('W-FRI').agg({'close': 'last'})
            w_close = w_df['close'].dropna()
        else:
            w_df = df_d.iloc[::5]
            w_close = w_df['close'].dropna()
        
    if not w_close.empty:
        w_ema10 = w_close.ewm(span=10, adjust=False).mean()
        w_r21 = compute_rsi(w_close, 21)
        w_r36 = compute_rsi(w_close, 36)
        w_r56 = compute_rsi(w_close, 56)
        
        # Reindex back to daily index safely
        if isinstance(df_d.index, (pd.DatetimeIndex, pd.PeriodIndex)):
            weekly_ema10 = w_ema10.reindex(df_d.index, method='ffill')
            rsi21_w = w_r21.reindex(df_d.index, method='ffill')
            rsi36_w = w_r36.reindex(df_d.index, method='ffill')
            rsi56_w = w_r56.reindex(df_d.index, method='ffill')
        elif "date" in df_d.columns:
            d_idx_dt = pd.to_datetime(df_d["date"], errors="coerce")
            w_df_all = pd.DataFrame({
                "weekly_ema10": w_ema10,
                "rsi21_w": w_r21,
                "rsi36_w": w_r36,
                "rsi56_w": w_r56,
            }).sort_index()
            temp_d = pd.DataFrame({"date": d_idx_dt, "_orig_idx": df_d.index})
            merged = pd.merge_asof(temp_d.sort_values("date"), w_df_all, left_on="date", right_index=True)
            merged = merged.sort_values("_orig_idx")
            weekly_ema10 = pd.Series(merged["weekly_ema10"].values, index=df_d.index)
            rsi21_w = pd.Series(merged["rsi21_w"].values, index=df_d.index)
            rsi36_w = pd.Series(merged["rsi36_w"].values, index=df_d.index)
            rsi56_w = pd.Series(merged["rsi56_w"].values, index=df_d.index)
        else:
            weekly_ema10 = pd.Series(w_ema10.iloc[-1] if len(w_ema10) > 0 else np.nan, index=df_d.index)
            rsi21_w = pd.Series(w_r21.iloc[-1] if len(w_r21) > 0 else np.nan, index=df_d.index)
            rsi36_w = pd.Series(w_r36.iloc[-1] if len(w_r36) > 0 else np.nan, index=df_d.index)
            rsi56_w = pd.Series(w_r56.iloc[-1] if len(w_r56) > 0 else np.nan, index=df_d.index)

    # Performance
    ret_1w = (close / close.shift(5) - 1.0) * 100.0
    ret_1m = (close / close.shift(21) - 1.0) * 100.0
    ret_3m = (close / close.shift(63) - 1.0) * 100.0

    # Recent Breakout Logic (15-bar breakout on 2x Relative Volume)
    volume = df_d["volume"] if "volume" in df_d.columns else pd.Series(1.0, index=df_d.index)
    adv20 = volume.rolling(20, min_periods=10).mean()
    rel_vol = volume / adv20
    
    cross_200 = (close > dma200) & (close.shift(1) <= dma200.shift(1))
    cross_52w = (close > high52w) & (close.shift(1) <= high52w.shift(1))
    is_breakout_day = (cross_200 | cross_52w) & (rel_vol > 2.0)
    recent_breakout = is_breakout_day.rolling(15).max().fillna(0) > 0

    # Bearish RSI Divergence (Fast Approximation)
    rolling_max_price_20d_ago = close.shift(10).rolling(20, min_periods=10).max()
    rolling_max_rsi_20d_ago = rsi21.shift(10).rolling(20, min_periods=10).max()
    price_making_higher_high = (close > rolling_max_price_20d_ago)
    rsi_making_lower_high = (rsi21 < rolling_max_rsi_20d_ago)
    bearish_div = price_making_higher_high & rsi_making_lower_high

    # Bollinger Band Width & ATR
    mid = close.rolling(20).mean()
    std = close.rolling(20).std()
    bbw = ((mid + 2*std) - (mid - 2*std)) / mid
    
    prev_close = close.shift(1)
    tr1 = high - low
    tr2 = (high - prev_close).abs()
    tr3 = (low - prev_close).abs()
    tr = pd.concat([tr1, tr2, tr3], axis=1).max(axis=1)
    atr = tr.ewm(alpha=1/14, adjust=False).mean()
    atr_pct = (atr / close) * 100.0
    
    def calc_pctile(s):
        s_clean = s[~np.isnan(s)]
        if len(s_clean) < 20: return 50.0
        return (np.sum(s_clean < s_clean[-1]) + 0.5 * np.sum(s_clean == s_clean[-1])) / len(s_clean) * 100.0
        
    bbw_pctile = bbw.rolling(100, min_periods=20).apply(calc_pctile, raw=True)
    bbw_pctile = bbw_pctile.fillna(50.0)

    return {
        "close": close,
        "dma200": dma200,
        "dma50": dma50,
        "ema21": ema21,
        "dist_from_high": dist_from_high,
        "dma50_slope": dma50_slope,
        "dma50_slope_pct": dma50_slope_pct,
        "price_vs_50dma_pct": price_vs_50dma_pct,
        "price_vs_200dma_pct": price_vs_200dma_pct,
        "adx": adx,
        "macd_hist": macd_hist,
        "stoch_k": stoch_k,
        "rsi21": rsi21,
        "rsi36": rsi36,
        "rsi56": rsi56,
        "rsi21_w": rsi21_w,
        "rsi36_w": rsi36_w,
        "rsi56_w": rsi56_w,
        "atr_pct": atr_pct,
        "ret_1w": ret_1w,
        "ret_1m": ret_1m,
        "ret_3m": ret_3m,
        "bbw_pctile": bbw_pctile,
        "weekly_ema10": weekly_ema10,
        "recent_breakout": recent_breakout,
        "bearish_div": bearish_div,
    }


# =========================================================================
# Stock Classification
# =========================================================================

def classify_stock_bucket(
    df_d: pd.DataFrame,
    df_w: pd.DataFrame = None,
    lookback_bars: int = 250,
    min_trading_days: int = 60,
) -> tuple[str, dict]:
    """Classify a stock into a bucket for DISPLAY purposes only."""
    
    metrics = compute_bucket_metrics(df_d, df_w)
    bucket = classify_bucket(metrics, -1)
    
    def _get(key, default=0.0):
        val = metrics[key].iloc[-1] if key in metrics and len(metrics[key]) > 0 else np.nan
        return round(val, 2) if not np.isnan(val) else default
    
    display_metrics = {
        "dist_from_52w_high": _get("dist_from_high"),
        "adx": _get("adx", 25.0),
        "bbw_pctile": _get("bbw_pctile", 50.0),
        "dma50_slope_pct": _get("dma50_slope_pct"),
        "price_vs_50dma_pct": _get("price_vs_50dma_pct"),
        "price_vs_200dma_pct": _get("price_vs_200dma_pct"),
        "macd_hist": _get("macd_hist"),
        "stoch_k": _get("stoch_k"),
        "rsi21": _get("rsi21"),
        "rsi36": _get("rsi36"),
        "rsi56": _get("rsi56"),
        "rsi21_w": _get("rsi21_w"),
        "rsi36_w": _get("rsi36_w"),
        "rsi56_w": _get("rsi56_w"),
        "atr_pct": _get("atr_pct"),
        "ret_1w": _get("ret_1w"),
        "ret_1m": _get("ret_1m"),
        "ret_3m": _get("ret_3m"),
    }

    return bucket, display_metrics

def pre_filter_bucket(df_d, df_w=None, lookback_bars=250, min_trading_days=60):
    """DEPRECATED - use classify_stock_bucket."""
    bucket, metrics = classify_stock_bucket(df_d, df_w, lookback_bars, min_trading_days)
    return False, bucket, metrics


# =========================================================================
# Layer 2: Per-Bar Classification
# =========================================================================

def classify_bucket(metrics: dict[str, pd.Series], bar_pos: int) -> str:
    """Classify a single bar into a bucket using Absolute Structural Logic."""
    
    def _safe(series, pos, default=np.nan):
        if len(series) == 0: return default
        if hasattr(series, "iloc"):
            val = series.iloc[pos]
        else:
            val = series[pos]
        return val if not np.isnan(val) else default

    close = _safe(metrics["close"], bar_pos)
    dma200 = _safe(metrics["dma200"], bar_pos)
    dma50 = _safe(metrics["dma50"], bar_pos)
    ema21 = _safe(metrics["ema21"], bar_pos)
    dist_high = _safe(metrics["dist_from_high"], bar_pos)
    dma50_slope = _safe(metrics["dma50_slope"], bar_pos)
    adx = _safe(metrics["adx"], bar_pos, 25.0)
    bbw_pctile = _safe(metrics["bbw_pctile"], bar_pos, 50.0)
    weekly_ema10 = _safe(metrics.get("weekly_ema10", pd.Series()), bar_pos)
    recent_breakout = _safe(metrics.get("recent_breakout", pd.Series()), bar_pos, False)
    bearish_div = _safe(metrics.get("bearish_div", pd.Series()), bar_pos, False)
    
    if np.isnan(close):
        return "IPO / New Listing"
        
    # --- Structural Decline ---
    if not np.isnan(dma50) and not np.isnan(dma200):
        if close < dma50 and dma50 < dma200 and dist_high < -30:
            return "Structural Decline"
            
    # --- Trending Up Tiers ---
    is_uptrend = False
    if not np.isnan(dist_high) and dist_high >= -15.0:
        is_uptrend = True
    if not np.isnan(dma50) and not np.isnan(dma200):
        if close > ema21 and ema21 > dma50 and dma50 > dma200:
            is_uptrend = True
            
    if is_uptrend:
        # Tier 1 (PRIME): Near ATH (5%) AND expanding momentum AND > Weekly 10 EMA
        if not np.isnan(dist_high) and dist_high >= -5.0 and adx > 25.0:
            if np.isnan(weekly_ema10) or close > weekly_ema10:
                return "Trending Up - Tier 1 (PRIME)"
        
        # Check momentum fading first (Tier 4 overrides T2/T3)
        if adx < 20.0 or bearish_div:
            return "Trending Up - Tier 4 (WATCH)"
            
        # Tier 2 (CONFIRMED): MA stack perfectly aligned
        if not np.isnan(dma50) and not np.isnan(dma200) and close > ema21 and ema21 > dma50 and dma50 > dma200:
            return "Trending Up - Tier 2 (CONFIRMED)"
            
        # Tier 3 (EMERGING): Breakout but stack not fully fanned
        if recent_breakout:
            return "Trending Up - Tier 3 (EMERGING)"
            
        # Default for uptrend that doesn't fit T1/T2 and has no breakout
        return "Trending Up - Tier 3 (EMERGING)"
            
    # --- Recovery ---
    if not np.isnan(dma50) and not np.isnan(dma200):
        if dma50 > dma200 and dist_high < -15.0:
            return "Recovery"
        if close > dma50 and dma50_slope > 0 and close < dma200:
            return "Recovery"
            
    # --- Sideways / Basing ---
    if adx < 20 or bbw_pctile < 20:
        return "Sideways / Basing"
        
    return "Sideways / Basing"

def get_score_multiplier(bucket: str) -> float:
    return SCORE_MULTIPLIERS.get(bucket, 1.0)
