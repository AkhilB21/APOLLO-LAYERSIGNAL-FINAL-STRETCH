"""LayerSignal Engine — Core Module (v20.1-fixed)

Computes longer-timeframe structural/trend scoring:
  - calc_momentum_score()   : 0-100 momentum score (5 sub-components)
  - compute_exit_layers()   : 0-100 exit pressure score (EL1-EL4)
  - evaluate_trade_signals(): state machine that steps through data,
                              returns (trades, metrics, final_state)
"""

from __future__ import annotations

import numpy as np
import pandas as pd


def calc_momentum_score(df, i):
    """Calculate the 100-point Momentum Score for bar index ``i``.

    Components (max points):
        1. Price Momentum  (25)
        2. RSI Strength     (25)
        3. Volume Confirm   (20)
        4. Multi-TF Approx  (20)
        5. Trend Quality    (10)

    Returns 0 when ``i < 30`` (insufficient lookback) or when key
    indicators are NaN.
    """
    if i < 30:
        return 0

    close = df["close"].values
    vol = df["volume"].values

    r21 = df["RSI rsi (21,C)"].iloc[i]
    r36 = df["RSI rsi (36)"].iloc[i]
    r56 = df["RSI rsi (56)"].iloc[i]

    # --- NaN guard: if primary RSI is invalid, score is 0 ---
    if np.isnan(r21):
        return 0

    # ----------------------------------------------------------------
    # 1. Price Momentum  (max 25 pts)
    # ----------------------------------------------------------------
    roc10 = (close[i] / close[i - 10] - 1) if close[i - 10] > 0 else 0
    roc20 = (close[i] / close[i - 20] - 1) if close[i - 20] > 0 else 0

    def roc_pts(v):
        if v >= 0.10:
            return 10
        if v >= 0.05:
            return 8
        if v >= 0.02:
            return 6
        if v >= 0:
            return 4
        if v >= -0.03:
            return 2
        return 0

    pm = roc_pts(roc10) + int(roc_pts(roc20) * 0.7)

    sma20 = df["SMA (20)"].iloc[i]
    if not np.isnan(sma20) and sma20 > 0:
        d = (close[i] - sma20) / sma20
        if d >= 0.05:
            pm += 5
        elif d >= 0.02:
            pm += 3
        elif d >= 0:
            pm += 1

    h20 = np.max(close[i - 20 : i + 1])
    near_high = sum(1 for c in close[i - 4 : i + 1] if c >= h20 * 0.98)
    pm += near_high * 1
    pm = min(25, pm)

    # ----------------------------------------------------------------
    # 2. RSI Strength  (max 25 pts)
    # ----------------------------------------------------------------
    rsi_pts = 0
    if r21 >= 75:
        rsi_pts = 12
    elif r21 >= 65:
        rsi_pts = 10
    elif r21 >= 55:
        rsi_pts = 7
    elif r21 >= 50:
        rsi_pts = 4
    elif r21 >= 45:
        rsi_pts = 2

    rsi_trend = 0
    if i >= 5:
        r21_5ago = df["RSI rsi (21,C)"].iloc[i - 5]
        if not np.isnan(r21) and not np.isnan(r21_5ago):
            delta = r21 - r21_5ago
            if delta > 5:
                rsi_trend = 8
            elif delta > 2:
                rsi_trend = 6
            elif delta > 0:
                rsi_trend = 4
            elif delta > -2:
                rsi_trend = 2

    # NaN-B fix: skip RSI stack when r36 or r56 is NaN
    stack = 0
    if not np.isnan(r36) and not np.isnan(r56):
        if r21 > r36 and r36 > r56:
            stack = 5
        elif r21 > r36:
            stack = 3

    rs = min(25, rsi_pts + rsi_trend + stack)

    # ----------------------------------------------------------------
    # 3. Volume Confirmation  (max 20 pts)
    # ----------------------------------------------------------------
    v20 = np.mean(vol[i - 20 : i])
    vm = (vol[i] / v20) if v20 > 0 else 1
    vol_ratio = 0
    if vm >= 2.0:
        vol_ratio = 10
    elif vm >= 1.5:
        vol_ratio = 8
    elif vm >= 1.2:
        vol_ratio = 6
    elif vm >= 1.0:
        vol_ratio = 4
    elif vm >= 0.8:
        vol_ratio = 2

    up_vol = sum(
        vol[j] for j in range(i - 20, i + 1) if close[j] > close[j - 1]
    )
    down_vol = sum(
        vol[j] for j in range(i - 20, i + 1) if close[j] < close[j - 1]
    )

    flow = 0
    if up_vol > 0 and down_vol > 0:
        ratio = up_vol / down_vol
        if ratio >= 1.5:
            flow = 10
        elif ratio >= 1.2:
            flow = 7
        elif ratio >= 1.0:
            flow = 4
        elif ratio >= 0.8:
            flow = 2
    elif up_vol > 0 and down_vol == 0:
        flow = 5
    else:
        # FLAT fix: both zero (flat/suspended price) -> no conviction
        flow = 0

    vc = min(20, vol_ratio + flow)

    # ----------------------------------------------------------------
    # 4. Multi-TF Approximation via daily RSI  (max 20 pts)
    # ----------------------------------------------------------------
    mtf = 0
    if r21 > 50:
        mtf += 10
    if not np.isnan(r36) and r36 > 50:
        mtf += 10

    # ----------------------------------------------------------------
    # 5. Trend Quality  (max 10 pts)
    # ----------------------------------------------------------------
    tq = 0
    sma50 = df["SMA (50)"].iloc[i]
    if not np.isnan(sma20) and not np.isnan(sma50) and sma20 > sma50:
        tq += 3
    if i >= 5:
        sma20_5ago = df["SMA (20)"].iloc[i - 5]
        if not np.isnan(sma20) and not np.isnan(sma20_5ago) and sma20 > sma20_5ago:
            tq += 3
    tq = min(10, tq)

    return pm + rs + vc + mtf + tq


def compute_exit_layers(df, i):
    """Calculate 0-100 Exit Pressure Score from 4 exit layers.

    Layers (max points):
        EL1: RSI drawdown from 90-bar peak   (30)
        EL2: Weighted RSI average below 47    (25)
        EL3: Price below 20-day low           (25)
        EL4: Price below 2% SL of 20-day low  (20)

    Returns 0 when ``i < 90`` (insufficient lookback).
    """
    if i < 90:
        return 0

    close = df["close"].values

    r21 = df["RSI rsi (21,C)"].iloc[i]
    r36 = df["RSI rsi (36)"].iloc[i]
    r56 = df["RSI rsi (56)"].iloc[i]

    if np.isnan(r21) or np.isnan(r36) or np.isnan(r56):
        return 0

    # EL1
    rsi_90 = df["RSI rsi (21,C)"].iloc[i - 90 : i + 1]
    peak_90 = rsi_90.max()
    if np.isnan(peak_90) or peak_90 <= 0:
        el1 = 0
    else:
        dd_pct = ((peak_90 - r21) / peak_90 * 100)
        el1_pct = min(100, (dd_pct / 7.5) * 100) if dd_pct > 0 else 0
        el1 = (el1_pct / 100) * 30

    # EL2
    w_avg = (r21 * 21 + r36 * 36 + r56 * 56) / 108
    el2_pct = 0 if w_avg >= 47 else ((47 - w_avg) / 47 * 100)
    el2 = (el2_pct / 100) * 25

    # EL3
    low20 = np.min(close[i - 20 : i])
    if low20 <= 0 or close[i] >= low20:
        el3 = 0
    else:
        el3_dist = ((low20 - close[i]) / low20 * 100)
        el3_pct = min(100, abs(el3_dist) / 5 * 100)
        el3 = (el3_pct / 100) * 25

    # EL4
    sl = low20 * 0.98
    if sl <= 0 or close[i] >= sl:
        el4 = 0
    else:
        el4_dist = ((sl - close[i]) / sl * 100)
        el4_pct = min(100, abs(el4_dist) / 3 * 100)
        el4 = (el4_pct / 100) * 20

    return int(el1 + el2 + el3 + el4)


def evaluate_trade_signals(df, symbol):
    """Step through ``df`` and extract trades.

    Returns
    -------
    trades : list[dict]
    metrics : dict
    state : dict
        Position state at the last bar.
    """
    in_trade = False
    entry_price = 0
    entry_date = None
    trades = []

    for i in range(100, len(df)):
        if not in_trade:
            score = calc_momentum_score(df, i)
            if score >= 75:
                in_trade = True
                entry_price = df["close"].iloc[i]
                entry_date = df["date"].iloc[i]
        else:
            exit_pressure = compute_exit_layers(df, i)
            if exit_pressure >= 70:
                exit_price = df["close"].iloc[i]
                exit_date = df["date"].iloc[i]
                ret = (exit_price - entry_price) / entry_price * 100
                trades.append(
                    {
                        "Symbol": symbol,
                        "Entry Date": entry_date.strftime("%Y-%m-%d")
                        if pd.notnull(entry_date)
                        else None,
                        "Exit Date": exit_date.strftime("%Y-%m-%d")
                        if pd.notnull(exit_date)
                        else None,
                        "Entry Price": entry_price,
                        "Exit Price": exit_price,
                        "Return (%)": round(ret, 2),
                    }
                )
                in_trade = False

    if in_trade:
        exit_price = df["close"].iloc[-1]
        exit_date = df["date"].iloc[-1]
        ret = (exit_price - entry_price) / entry_price * 100
        trades.append(
            {
                "Symbol": symbol,
                "Entry Date": entry_date.strftime("%Y-%m-%d")
                if pd.notnull(entry_date)
                else None,
                "Exit Date": exit_date.strftime("%Y-%m-%d")
                if pd.notnull(exit_date)
                else None,
                "Entry Price": entry_price,
                "Exit Price": exit_price,
                "Return (%)": round(ret, 2),
                "Note": "Open Trade (Marked to Market)",
            }
        )

    wins = [t for t in trades if t["Return (%)"] > 0]
    win_rate = (len(wins) / len(trades) * 100) if trades else 0
    total_ret = sum(t["Return (%)"] for t in trades) if trades else 0

    metrics = {
        "Symbol": symbol,
        "Trades": len(trades),
        "WinRate": round(win_rate, 1),
        "TotalReturn": round(total_ret, 1),
    }

    last_momentum = calc_momentum_score(df, len(df) - 1)
    last_exit_pressure = compute_exit_layers(df, len(df) - 1)
    state = {
        "in_trade": in_trade,
        "entry_price": entry_price if in_trade else None,
        "entry_date": entry_date.strftime("%Y-%m-%d")
        if in_trade and pd.notnull(entry_date)
        else None,
        "last_momentum": float(last_momentum),
        "last_exit_pressure": float(last_exit_pressure),
    }

    return trades, metrics, state
