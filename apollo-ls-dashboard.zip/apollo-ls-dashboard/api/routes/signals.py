"""FastAPI Routes for Signals."""

from fastapi import APIRouter, Query
from api.models.signals import SignalsResponse
from api.services.signals_service import SignalsService

router = APIRouter(prefix="/api", tags=["signals"])
signals_service = SignalsService()


@router.get("/signals", response_model=SignalsResponse)
async def get_signals(force_refresh: bool = Query(False)):
    """Retrieve scored stocks and summary metrics for the React Dashboard."""
    # In live/orchestrated environment, signals_service.get_signals() will return full universe.
    # Currently wired for single and batch evaluation.
    return {
        "stocks": [],
        "summary": signals_service.compute_summary([])
    }


@router.post("/signals/sync")
async def sync_signals():
    """Invalidate cache and trigger immediate rescore."""
    signals_service.invalidate_cache()
    return {"status": "ok", "message": "Cache invalidated successfully"}
