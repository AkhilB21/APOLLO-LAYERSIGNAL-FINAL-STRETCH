"""Apollo-LS API Routes Package."""
from api.routes.signals import router as signals_router

__all__ = ["signals_router"]
