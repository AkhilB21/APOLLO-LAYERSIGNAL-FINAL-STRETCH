"""Apollo-LS Signals Service Orchestration Layer.

Orchestrates the 7-stage computation pipeline across the 8 extracted kernel files:
  1. Indicators computation with COLUMN_MAP aliasing
  2. Renko bricks and RSI computation
  3. Apollo scoring & action classification
  4. LayerSignal momentum scoring & exit pressure computation (float-wrapped)
  5. Gates evaluation (G1-G4 with PE=None, G5 computed)
  6. Bucket classification & metrics extraction
  7. 49-field SignalStock response assembly
"""

from __future__ import annotations
import os
import time
from datetime import datetime
from typing import Optional, List, Dict, Any, Tuple
import numpy as np
import pandas as pd

from core.constants import (
    ENTRY_THRESHOLD,
    EXIT_THRESHOLD,
    SIGNAL_DEFS,
    POOL_NAMES,
)
from core.indicators import compute_all_indicators, detect_trough_rsi, compute_rsi
from core.scoring import eval_signals, classify_score, get_latest_trough_pos
from core.renko import (
    compute_renko_bricks,
    compute_renko_rsi,
    eval_renko_signals,
    map_renko_to_daily,
)
from core.layersignal import calc_momentum_score, compute_exit_layers
from core.gates import compute_gate_frame, evaluate_gate_row
from core.bucket_classifier import classify_stock_bucket
from api.models.signals import (
    SignalStock,
    SignalsSummary,
    SignalsResponse,
    SubScores,
    HistoricalL3Event,
    BucketBreakdown,
    QualityBreakdown,
)

COLUMN_MAP = {
    "RSI rsi (21,C)": "rsi21",
    "RSI rsi (36)": "rsi36",
    "RSI rsi (56)": "rsi56",
    "SMA (20)": "sma20",
    "SMA (50)": "sma50",
    "ADX ADX (14,14,y,n)": "adx",
    "+DI ADX (14,14,y,n)": "plus_di",
    "-DI ADX (14,14,y,n)": "minus_di",
    "ATR (14)": "atr",
    "MACD macd (12,26,9)": "macd_line",
    "Signal macd (12,26,9)": "macd_signal",
    "macd (12,26,9)_hist": "macd_hist",
    "Stoch %K (14,3)": "stoch_k",
    "Stoch %D (14,3)": "stoch_d",
    "VPT (1)": "vpt",
    "Result Typical Price (28,n)": "tp28",
    "Result Weighted Close (50,y)": "wc50",
    "Result Weighted Close (21)": "wc21",
}

BUCKET_TIER_MAP = {
    "Trending Up - Tier 1 (PRIME)": "L1",
    "Trending Up - Tier 2 (CONFIRMED)": "L2",
    "Trending Up - Tier 3 (EMERGING)": "L3",
    "Trending Up - Tier 4 (WATCH)": "L4",
    "Recovery": "L3",
    "Sideways / Basing": "L4",
    "Structural Decline": "L4",
    "IPO / New Listing": "L3",
}


class SignalsService:
    """Orchestration service for generating real-time SignalStock arrays."""

    def __init__(self, cache_ttl_seconds: int = 300):
        self._cache: Optional[SignalsResponse] = None
        self._cache_time: float = 0.0
        self._cache_ttl: int = cache_ttl_seconds

    def invalidate_cache(self) -> None:
        self._cache = None
        self._cache_time = 0.0

    def score_single_df(
        self,
        symbol: str,
        df_daily: pd.DataFrame,
        df_4h: Optional[pd.DataFrame] = None,
        df_weekly: Optional[pd.DataFrame] = None,
    ) -> Optional[SignalStock]:
        """Run the full 7-stage engine on a stock DataFrame and return SignalStock."""
        if df_daily is None or len(df_daily) < 30:
            return None

        # Standardize column casing for input DataFrame
        df_d = df_daily.copy()
        df_d.columns = [c.lower() for c in df_d.columns]
        if "date" not in df_d.columns and "date" in df_daily.columns:
            df_d["date"] = df_daily["date"]

        # Ensure required columns exist
        for req_col in ("open", "high", "low", "close"):
            if req_col not in df_d.columns:
                return None
        if "volume" not in df_d.columns:
            df_d["volume"] = 100000.0

        n_bars = len(df_d)
        d_idx = n_bars - 1

        # -------------------------------------------------------------
        # Stage 1: Indicators Computation & Column Mapping
        # -------------------------------------------------------------
        df_enriched = compute_all_indicators(df_d)
        # Keep a copy with original ChartAlert names for layersignal
        df_layersignal = df_enriched.copy()
        # Create renamed DataFrame for clean downstream reads
        df_clean = df_enriched.rename(columns=COLUMN_MAP)

        # -------------------------------------------------------------
        # Stage 2: Renko Computation
        # -------------------------------------------------------------
        try:
            renko_bricks = compute_renko_bricks(df_d)
            if len(renko_bricks) > 0:
                renko_rsi = compute_renko_rsi(renko_bricks)
                renko_map = map_renko_to_daily(renko_bricks, df_d)
                r_idx = int(renko_map.iloc[d_idx]) if d_idx < len(renko_map) else -1
                if r_idx >= 0:
                    renko_signals = eval_renko_signals(
                        renko_daily=renko_bricks,
                        renko_4h=None,
                        r_idx=r_idx,
                        renko_rsi=renko_rsi,
                    )
                    last_dir = renko_bricks["direction"].iloc[r_idx] if r_idx < len(renko_bricks) else 0
                    renko_status = "GREEN" if last_dir == 1 else ("RED" if last_dir == -1 else "NEUTRAL")
                else:
                    renko_signals = {}
                    renko_status = "NEUTRAL"
            else:
                renko_signals = {}
                renko_status = "NEUTRAL"
        except Exception:
            renko_signals = {}
            renko_status = "NEUTRAL"

        # -------------------------------------------------------------
        # Stage 3: Apollo Scoring
        # -------------------------------------------------------------
        # Detect troughs on daily RSI
        d_rsi_series = df_clean["rsi21"]
        d_troughs = detect_trough_rsi(d_rsi_series, rsi_threshold=40.0, window=11)
        d_trough_pos = get_latest_trough_pos(d_troughs, d_idx)

        # Prepare 4H mock/actual data
        if df_4h is not None and len(df_4h) > 0:
            df_4h_enriched = compute_all_indicators(df_4h).rename(columns=COLUMN_MAP)
            h_idx = len(df_4h_enriched) - 1
            h_rsi_series = df_4h_enriched["rsi21"]
            h_troughs = detect_trough_rsi(h_rsi_series, rsi_threshold=38.0, window=5)
            h_trough_pos = get_latest_trough_pos(h_troughs, h_idx)
            df_4h_dict = {col: df_4h_enriched[col].values for col in df_4h_enriched.columns}
            h_dates = pd.to_datetime(df_4h_enriched["date"]).values if "date" in df_4h_enriched else np.arange(len(df_4h_enriched))
            h_rsi21 = df_4h_enriched["rsi21"].values
            h_rsi36 = df_4h_enriched["rsi36"].values
        else:
            # Fallback to daily approximations if 4H not available
            df_4h_dict = {col: df_clean[col].values for col in df_clean.columns}
            h_idx = d_idx
            h_trough_pos = d_trough_pos
            h_dates = pd.to_datetime(df_clean["date"]).values if "date" in df_clean else np.arange(len(df_clean))
            h_rsi21 = df_clean["rsi21"].values
            h_rsi36 = df_clean["rsi36"].values

        # Prepare weekly data
        if df_weekly is not None and len(df_weekly) > 0:
            df_w_enriched = compute_all_indicators(df_weekly).rename(columns=COLUMN_MAP)
            w_idx = len(df_w_enriched) - 1
            df_w_dict = {col: df_w_enriched[col].values for col in df_w_enriched.columns}
            w_rsi21 = df_w_enriched["rsi21"].values
            w_rsi56 = df_w_enriched["rsi56"].values
        else:
            df_w_dict = {col: df_clean[col].values for col in df_clean.columns}
            w_idx = d_idx
            w_rsi21 = df_clean["rsi21"].values
            w_rsi56 = df_clean["rsi56"].values

        df_d_dict = {col: df_clean[col].values for col in df_clean.columns}
        d_dates = pd.to_datetime(df_clean["date"]).values if "date" in df_clean else np.arange(len(df_clean))

        # Add helper column for BB2 if not present
        if "low_rolling_min_21" not in df_d_dict:
            df_d_dict["low_rolling_min_21"] = df_clean["low"].rolling(21, min_periods=10).min().values

        apollo_signals = eval_signals(
            df_d=df_d_dict,
            df_4h=df_4h_dict,
            df_w=df_w_dict,
            d_dates=d_dates,
            h_dates=h_dates,
            d_idx=d_idx,
            h_idx=h_idx,
            w_idx=w_idx,
            d_trough_pos=d_trough_pos,
            h_trough_pos=h_trough_pos,
            d_rsi21=df_clean["rsi21"].values,
            d_rsi36=df_clean["rsi36"].values,
            h_rsi21=h_rsi21,
            h_rsi36=h_rsi36,
            w_rsi21=w_rsi21,
            w_rsi56=w_rsi56,
            plus_di=df_clean["plus_di"].values,
            minus_di=df_clean["minus_di"].values,
            macd_line=df_clean["macd_line"].values,
            crossover_price=None,
        )

        # Merge Renko signals into scoring results
        for r_k, r_v in renko_signals.items():
            apollo_signals[r_k] = r_v

        # Total Apollo Score is sum of all fired points
        raw_score = sum(pts for pts, fired in apollo_signals.values() if fired)
        apollo_score = float(round(raw_score, 1))

        # Classify score
        r_pts = sum(pts for k, (pts, fired) in apollo_signals.items() if k.startswith("R") and fired)
        apollo_action_label, _ = classify_score(apollo_score, r_points=r_pts)

        # -------------------------------------------------------------
        # Stage 4: LayerSignal Scoring (float-wrapped boundary)
        # -------------------------------------------------------------
        ls_score = float(calc_momentum_score(df_layersignal, d_idx))
        exit_pressure = float(compute_exit_layers(df_layersignal, d_idx))

        # LayerSignal action determination
        if ls_score >= 75 and exit_pressure < 50:
            ls_action = "ENTRY"
        elif exit_pressure >= 70:
            ls_action = "EXIT"
        elif ls_score >= 50:
            ls_action = "HOLD"
        else:
            ls_action = "FLAT"

        # ELStatus mapping
        if exit_pressure >= 85:
            el_status = "EL4"
        elif exit_pressure >= 70:
            el_status = "EL3"
        elif exit_pressure >= 50:
            el_status = "EL2"
        elif exit_pressure >= 30:
            el_status = "EL1"
        else:
            el_status = "NONE"

        # -------------------------------------------------------------
        # Stage 5: Gate Evaluation (pe=None)
        # -------------------------------------------------------------
        gate_frame = compute_gate_frame(df_d)
        last_gate_row = gate_frame.iloc[d_idx]
        gate_results = evaluate_gate_row(last_gate_row, pe=None)

        # G5 Quality Check: RSI stack alignment (RSI21 > RSI36 > RSI56)
        r21_val = float(df_clean["rsi21"].iloc[d_idx])
        r36_val = float(df_clean["rsi36"].iloc[d_idx])
        r56_val = float(df_clean["rsi56"].iloc[d_idx])
        g5_pass = bool(
            not np.isnan(r21_val) and not np.isnan(r36_val) and not np.isnan(r56_val)
            and r21_val > r36_val > r56_val and 40.0 <= r21_val <= 70.0
        )

        gates_bool = [
            bool(gate_results.get("g1_status") == "OK"),
            bool(gate_results.get("g2_status") == "OK"),
            bool(gate_results.get("g3_status") == "OK"),
            bool(gate_results.get("g4_status") == "OK"),
            g5_pass,
        ]

        gates_explanations = [
            "G1 PE: Passed (Informational)",
            f"G2 Liquidity: {gate_results.get('g2_status', 'OK')}",
            f"G3 52W-Low: {gate_results.get('g3_status', 'OK')}",
            f"G4 52W-High: {gate_results.get('g4_status', 'OK')}",
            f"G5 RSI Stack: {'OK' if g5_pass else 'MISALIGNED'}",
        ]

        # -------------------------------------------------------------
        # Stage 6: Bucket Classification & Metrics
        # -------------------------------------------------------------
        bucket_label, display_metrics = classify_stock_bucket(df_d, df_weekly)
        bucket_tier = BUCKET_TIER_MAP.get(bucket_label, "L3")

        # -------------------------------------------------------------
        # Stage 7: Response Assembly
        # -------------------------------------------------------------
        close_price = float(df_d["close"].iloc[d_idx])
        open_price = float(df_d["open"].iloc[d_idx])
        high_price = float(df_d["high"].iloc[d_idx])
        low_price = float(df_d["low"].iloc[d_idx])
        volume_val = float(df_d["volume"].iloc[d_idx])

        prev_close = float(df_d["close"].iloc[d_idx - 1]) if d_idx > 0 else close_price
        pct_change = round(((close_price - prev_close) / prev_close) * 100.0, 2) if prev_close > 0 else 0.0

        high52w = float(df_d["high"].rolling(252, min_periods=min(30, len(df_d))).max().iloc[d_idx])
        low52w = float(df_d["low"].rolling(252, min_periods=min(30, len(df_d))).min().iloc[d_idx])

        prox_52w = round((close_price / high52w) * 100.0, 1) if high52w > 0 else 100.0
        traded_val = round(close_price * volume_val, 0)

        # MCap categorization
        if traded_val > 500_000_000:
            mcap = "Large"
        elif traded_val > 100_000_000:
            mcap = "Mid"
        else:
            mcap = "Small"

        # FQS grading
        if apollo_score >= 110:
            fqs = "A"
        elif apollo_score >= 85:
            fqs = "B"
        elif apollo_score >= 60:
            fqs = "C"
        else:
            fqs = "D"

        # Moving Averages
        sma20_val = float(df_clean["sma20"].iloc[d_idx]) if "sma20" in df_clean and not np.isnan(df_clean["sma20"].iloc[d_idx]) else None
        sma50_val = float(df_clean["sma50"].iloc[d_idx]) if "sma50" in df_clean and not np.isnan(df_clean["sma50"].iloc[d_idx]) else None
        sma200_series = df_d["close"].rolling(200, min_periods=100).mean()
        sma200_val = float(sma200_series.iloc[d_idx]) if not np.isnan(sma200_series.iloc[d_idx]) else None

        # Sparkline (last 10-20 closes)
        sparkline_data = [float(round(c, 2)) for c in df_d["close"].iloc[max(0, d_idx - 19) : d_idx + 1].tolist()]

        # Throwback alert
        throwback = bool(sma20_val and sma50_val and close_price < sma20_val and sma20_val >= sma50_val and apollo_score >= 55)

        # Date string
        if "date" in df_d.columns:
            date_val = str(df_d["date"].iloc[d_idx])[:10]
        else:
            date_val = datetime.utcnow().strftime("%Y-%m-%d")

        # SubScores
        sub_scores = SubScores(
            trend=float(round(sum(pts for k, (pts, f) in apollo_signals.items() if k.startswith("A") and f), 1)),
            momentum=float(round(sum(pts for k, (pts, f) in apollo_signals.items() if k.startswith("B") and f), 1)),
            volatility=float(round(sum(pts for k, (pts, f) in apollo_signals.items() if k.startswith("C") and f), 1)),
            volume=float(round(sum(pts for k, (pts, f) in apollo_signals.items() if (k.startswith("BA") or k.startswith("E")) and f), 1)),
            marketFilter=float(round(sum(pts for k, (pts, f) in apollo_signals.items() if k.startswith("R") and f), 1)),
        )

        conviction = round(min(1.0, max(0.0, apollo_score / 148.0)), 2)

        return SignalStock(
            Symbol=symbol,
            Date=date_val,
            Apollo_Action=apollo_action_label,
            Apollo_Score=apollo_score,
            Pct_Change=pct_change,
            LayerSignal_Action=ls_action,
            LayerSignal_Score=ls_score,
            Exit_Pressure=exit_pressure,
            Open=open_price,
            High=high_price,
            Low=low_price,
            Close=close_price,
            Volume=volume_val,
            High52W=high52w,
            Low52W=low52w,
            RSI21=round(r21_val, 1) if not np.isnan(r21_val) else 50.0,
            RSI36=round(r36_val, 1) if not np.isnan(r36_val) else 50.0,
            RSI56=round(r56_val, 1) if not np.isnan(r56_val) else 50.0,
            ADX=round(float(df_clean["adx"].iloc[d_idx]), 1) if not np.isnan(df_clean["adx"].iloc[d_idx]) else 25.0,
            ATR_Pct=round(float(df_clean["atr"].iloc[d_idx] / close_price * 100.0), 2) if not np.isnan(df_clean["atr"].iloc[d_idx]) and close_price > 0 else 2.0,
            SMA_20D=round(sma20_val, 2) if sma20_val is not None else None,
            SMA_50D=round(sma50_val, 2) if sma50_val is not None else None,
            SMA_200D=round(sma200_val, 2) if sma200_val is not None else None,
            PE=None,  # Fundamental PE always omitted/null for VPS
            Stochastic=round(float(df_clean["stoch_k"].iloc[d_idx]), 1) if not np.isnan(df_clean["stoch_k"].iloc[d_idx]) else 50.0,
            Prox_52W=prox_52w,
            CMP=close_price,
            Traded_Value=traded_val,
            Bucket=bucket_tier,
            LStage=bucket_label,
            ELStatus=el_status,
            Conviction=conviction,
            Gates=gates_bool,
            Renko=renko_status,
            MCap=mcap,
            FQS=fqs,
            Sparkline=sparkline_data,
            ThrowbackAlert=throwback,
            ml_confidence=None,
            SubScores=sub_scores,
            GatesExplanations=gates_explanations,
            HistoricalL3Events=[],
            isIPO=False,
            ipoData=None,
        )

    def compute_summary(self, stocks: List[SignalStock]) -> SignalsSummary:
        """Compute aggregate universe summary from scored stocks."""
        total = len(stocks)
        if total == 0:
            return SignalsSummary(
                total=0, liquid=0, scored=0, signalBearing=0,
                ENTRY=0, HOLD=0, EXIT=0, FLAT=0, OTHER=0,
                avgScore=0.0, avgExitPressure=0.0,
                buckets=BucketBreakdown(), quality=QualityBreakdown(),
                generatedAt=datetime.utcnow().isoformat(),
            )

        entry_count = sum(1 for s in stocks if s.Apollo_Action in ("FULL STRONG", "FULL ENTRY", "STANDARD"))
        hold_count = sum(1 for s in stocks if s.Apollo_Action == "WATCHLIST")
        exit_count = sum(1 for s in stocks if s.LayerSignal_Action == "EXIT")
        flat_count = sum(1 for s in stocks if s.Apollo_Action == "DO NOT ENTER")
        other_count = total - (entry_count + hold_count + exit_count + flat_count)

        avg_score = round(sum(s.Apollo_Score for s in stocks) / total, 1)
        avg_ep = round(sum(s.Exit_Pressure for s in stocks) / total, 1)

        buckets = BucketBreakdown(
            L1=sum(1 for s in stocks if s.Bucket == "L1"),
            L2=sum(1 for s in stocks if s.Bucket == "L2"),
            L3=sum(1 for s in stocks if s.Bucket == "L3"),
            L4=sum(1 for s in stocks if s.Bucket == "L4"),
        )

        quality = QualityBreakdown(
            STRONG=sum(1 for s in stocks if s.FQS == "A"),
            GOOD=sum(1 for s in stocks if s.FQS == "B"),
            MODERATE=sum(1 for s in stocks if s.FQS == "C"),
            WEAK=sum(1 for s in stocks if s.FQS == "D"),
        )

        return SignalsSummary(
            total=total,
            liquid=sum(1 for s in stocks if s.Gates[1]),
            scored=total,
            signalBearing=sum(1 for s in stocks if s.Apollo_Score >= 50),
            ENTRY=entry_count,
            HOLD=hold_count,
            EXIT=exit_count,
            FLAT=flat_count,
            OTHER=max(0, other_count),
            avgScore=avg_score,
            avgExitPressure=avg_ep,
            buckets=buckets,
            quality=quality,
            generatedAt=datetime.utcnow().isoformat(),
        )
