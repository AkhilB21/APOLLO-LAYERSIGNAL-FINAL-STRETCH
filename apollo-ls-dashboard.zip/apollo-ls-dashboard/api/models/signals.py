"""Pydantic models for Apollo-LS Signals matching the React 49-field contract."""

from __future__ import annotations
from typing import Optional, List, Dict, Any
from pydantic import BaseModel, Field, ConfigDict


class SubScoresModel(BaseModel):
    trend: float = 0.0
    momentum: float = 0.0
    volatility: float = 0.0
    volume: float = 0.0
    marketFilter: float = 0.0


# Backward compatibility alias
SubScores = SubScoresModel


class HistoricalL3Event(BaseModel):
    date: str
    event: str
    price: float
    outcomePct: float


class SignalStock(BaseModel):
    model_config = ConfigDict(populate_by_name=True, serialize_by_alias=True)

    # Core Identifiers
    Symbol: str
    Date: str

    # Apollo Action & Scores
    Apollo_Action: str
    Apollo_Score: float
    Pct_Change: float

    # LayerSignal Action & Scores
    LayerSignal_Action: str
    LayerSignal_Score: float
    Exit_Pressure: float

    # Raw OHLCV Prices
    Open: float
    High: float
    Low: float
    Close: float
    Volume: float
    High52W: float
    Low52W: float

    # Technical Indicators
    RSI21: float
    RSI36: float
    RSI56: float
    ADX: float
    ATR_Pct: float
    SMA_20D: Optional[float] = Field(default=None, alias="20D_SMA")
    SMA_50D: Optional[float] = Field(default=None, alias="50D_SMA")
    SMA_200D: Optional[float] = Field(default=None, alias="200D_SMA")
    PE: Optional[float] = None
    Stochastic: float
    Prox_52W: float = Field(..., alias="52W_Prox")
    CMP: float
    Traded_Value: float

    # Structural Buckets & Status
    Bucket: str  # L1, L2, L3, L4
    LStage: str
    ELStatus: str  # EL1, EL2, EL3, EL4, NONE
    Conviction: float
    Gates: List[bool]  # [G1, G2, G3, G4, G5]
    Renko: str  # GREEN, RED, NEUTRAL
    MCap: str  # Large, Mid, Small
    FQS: str  # A, B, C, D
    Sparkline: List[float]

    # Optional Enrichments
    ThrowbackAlert: Optional[bool] = None
    ml_confidence: Optional[float] = None
    SubScores: Optional[SubScoresModel] = None
    GatesExplanations: Optional[List[str]] = None
    HistoricalL3Events: Optional[List[HistoricalL3Event]] = None
    isIPO: Optional[bool] = None
    ipoData: Optional[Dict[str, Any]] = None


class BucketBreakdown(BaseModel):
    L1: int = 0
    L2: int = 0
    L3: int = 0
    L4: int = 0


class QualityBreakdown(BaseModel):
    STRONG: int = 0
    GOOD: int = 0
    MODERATE: int = 0
    WEAK: int = 0


class SignalsSummary(BaseModel):
    total: int
    liquid: int
    scored: int
    signalBearing: int
    ENTRY: int
    HOLD: int
    EXIT: int
    FLAT: int
    OTHER: int
    avgScore: float
    avgExitPressure: float
    buckets: BucketBreakdown
    quality: QualityBreakdown
    generatedAt: str


class SignalsResponse(BaseModel):
    stocks: List[SignalStock]
    summary: SignalsSummary
