"""Apollo-LS Dashboard Backend Entry Point."""

from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware
from api.routes.signals import router as signals_router

app = FastAPI(
    title="Apollo-LS Dashboard Backend",
    description="VPS/Cloud calculation backend powering the Apollo-LayerSignal React Dashboard",
    version="1.0.0",
)

# Allow CORS for React frontend (Vite port 5173 and Express port 3000)
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

app.include_router(signals_router)


@app.get("/api/health")
async def health():
    return {"status": "healthy", "service": "apollo-ls-backend", "version": "1.0.0"}


if __name__ == "__main__":
    import uvicorn
    uvicorn.run("main:app", host="0.0.0.0", port=8000, reload=True)
