"""Comprehensive 14-Point Automated Smoke Test Suite for Apollo-LS Kernel Extraction."""

import os
import sys
import glob
import numpy as np
import pandas as pd

# Add project root to sys.path
PROJECT_ROOT = os.path.dirname(os.path.abspath(__file__))
if PROJECT_ROOT not in sys.path:
    sys.path.insert(0, PROJECT_ROOT)

def run_all_tests():
    passed = 0
    total = 14
    print("=" * 70)
    print("APOLLO-LS RUNTIME COMPUTATION KERNEL: 14-POINT SMOKE TEST SUITE")
    print("=" * 70)

    # -----------------------------------------------------------------
    # Check 1: All 8 kernel files exist in core/
    # -----------------------------------------------------------------
    expected_files = [
        "__init__.py", "scoring.py", "indicators.py", "gates.py",
        "bucket_classifier.py", "renko.py", "layersignal.py",
        "constants.py", "types.py"
    ]
    core_files = [os.path.basename(f) for f in glob.glob(os.path.join(PROJECT_ROOT, "core", "*.py"))]
    missing = [f for f in expected_files if f not in core_files]
    assert len(missing) == 0, f"Missing kernel files: {missing}"
    print(f"[PASS 1/14] All 8 kernel files present in core/ ({len(core_files)} python files found)")
    passed += 1

    # -----------------------------------------------------------------
    # Check 2: No import errors across all kernel modules
    # -----------------------------------------------------------------
    from core.scoring import eval_signals, classify_score
    from core.indicators import compute_all_indicators
    from core.gates import compute_gate_frame, evaluate_gate_row
    from core.bucket_classifier import classify_stock_bucket
    from core.renko import eval_renko_signals, compute_renko_bricks, compute_renko_rsi, map_renko_to_daily
    from core.layersignal import calc_momentum_score, compute_exit_layers
    from core.constants import SIGNAL_DEFS, POOL_MAX
    from core.types import SignalResult
    print("[PASS 2/14] All 8 kernel modules import cleanly with zero errors")
    passed += 1

    # Generate synthetic 250-bar realistic OHLCV test dataset
    np.random.seed(42)
    dates = pd.date_range(end="2026-08-28", periods=250, freq="B")
    close_prices = np.cumprod(1 + np.random.normal(0.001, 0.02, 250)) * 100.0
    high_prices = close_prices * (1 + np.random.uniform(0.005, 0.03, 250))
    low_prices = close_prices * (1 - np.random.uniform(0.005, 0.03, 250))
    open_prices = low_prices + (high_prices - low_prices) * np.random.uniform(0.2, 0.8, 250)
    volumes = np.random.uniform(100_000, 1_000_000, 250)

    test_df = pd.DataFrame({
        "date": dates,
        "open": open_prices,
        "high": high_prices,
        "low": low_prices,
        "close": close_prices,
        "volume": volumes,
    })

    # -----------------------------------------------------------------
    # Check 3: compute_all_indicators() works & returns 17 extra columns
    # -----------------------------------------------------------------
    df_enriched = compute_all_indicators(test_df)
    assert len(df_enriched.columns) >= len(test_df.columns) + 17
    print(f"[PASS 3/14] compute_all_indicators() succeeded: {len(df_enriched.columns)} total columns generated")
    passed += 1

    # -----------------------------------------------------------------
    # Check 4: COLUMN_MAP aliases ChartAlert names properly
    # -----------------------------------------------------------------
    from api.services.signals_service import COLUMN_MAP
    df_clean = df_enriched.rename(columns=COLUMN_MAP)
    assert "rsi21" in df_clean.columns
    assert "sma20" in df_clean.columns
    assert "macd_line" in df_clean.columns
    print("[PASS 4/14] COLUMN_MAP applied: verified clean column identifiers ('rsi21', 'sma20', 'macd_line')")
    passed += 1

    # -----------------------------------------------------------------
    # Check 5: eval_signals() returns dict of tuples with 26+ signal keys
    # -----------------------------------------------------------------
    d_idx = len(df_clean) - 1
    df_dict = {col: df_clean[col].values for col in df_clean.columns}
    df_dict["low_rolling_min_21"] = df_clean["low"].rolling(21, min_periods=10).min().values
    d_dates = pd.to_datetime(df_clean["date"]).values

    sig_results = eval_signals(
        df_d=df_dict,
        df_4h=df_dict,
        df_w=df_dict,
        d_dates=d_dates,
        h_dates=d_dates,
        d_idx=d_idx,
        h_idx=d_idx,
        w_idx=d_idx,
        d_trough_pos=d_idx - 5,
        h_trough_pos=d_idx - 3,
        d_rsi21=df_clean["rsi21"].values,
        d_rsi36=df_clean["rsi36"].values,
        h_rsi21=df_clean["rsi21"].values,
        h_rsi36=df_clean["rsi36"].values,
        w_rsi21=df_clean["rsi21"].values,
        w_rsi56=df_clean["rsi56"].values,
        plus_di=df_clean["plus_di"].values,
        minus_di=df_clean["minus_di"].values,
        macd_line=df_clean["macd_line"].values,
        crossover_price=None,
    )
    assert isinstance(sig_results, dict)
    assert len(sig_results) >= 26
    for k, (pts, fired) in sig_results.items():
        assert isinstance(pts, (int, float))
        assert isinstance(fired, (bool, np.bool_))
    print(f"[PASS 5/14] eval_signals() returned {len(sig_results)} signal (points, fired) tuples")
    passed += 1

    # -----------------------------------------------------------------
    # Check 6: classify_score() returns valid (action, pos_pct) tuple
    # -----------------------------------------------------------------
    action_lbl, pos_str = classify_score(85.0, r_points=10.0)
    assert action_lbl in ("FULL STRONG", "FULL ENTRY", "STANDARD", "WATCHLIST", "DO NOT ENTER", "RENKO GATED")
    assert "%" in pos_str
    print(f"[PASS 6/14] classify_score(85.0, 10.0) -> ('{action_lbl}', '{pos_str}')")
    passed += 1

    # -----------------------------------------------------------------
    # Check 7: calc_momentum_score() float wrapper
    # -----------------------------------------------------------------
    ls_score = float(calc_momentum_score(df_enriched, d_idx))
    assert isinstance(ls_score, float)
    assert 0.0 <= ls_score <= 100.0
    print(f"[PASS 7/14] calc_momentum_score() float-wrapped -> {ls_score} (type: {type(ls_score).__name__})")
    passed += 1

    # -----------------------------------------------------------------
    # Check 8: compute_exit_layers() float wrapper
    # -----------------------------------------------------------------
    exit_p = float(compute_exit_layers(df_enriched, d_idx))
    assert isinstance(exit_p, float)
    assert 0.0 <= exit_p <= 100.0
    print(f"[PASS 8/14] compute_exit_layers() float-wrapped -> {exit_p} (type: {type(exit_p).__name__})")
    passed += 1

    # -----------------------------------------------------------------
    # Check 9: evaluate_gate_row(pe=None) works & passes informational
    # -----------------------------------------------------------------
    gate_frame = compute_gate_frame(test_df)
    gate_res = evaluate_gate_row(gate_frame.iloc[-1], pe=None)
    assert gate_res["g1_pe"] is None
    assert gate_res["g1_status"] == "OK"
    assert "all_pass" in gate_res
    print(f"[PASS 9/14] evaluate_gate_row(pe=None) -> g1_pe=None, g1_status='OK', all_pass={gate_res['all_pass']}")
    passed += 1

    # -----------------------------------------------------------------
    # Check 10: classify_stock_bucket() returns (bucket_str, 18 metrics)
    # -----------------------------------------------------------------
    bucket_str, metrics_dict = classify_stock_bucket(test_df)
    assert isinstance(bucket_str, str)
    assert isinstance(metrics_dict, dict)
    assert len(metrics_dict) == 18
    print(f"[PASS 10/14] classify_stock_bucket() -> Bucket: '{bucket_str}', Metrics: {len(metrics_dict)} keys")
    passed += 1

    # -----------------------------------------------------------------
    # Check 11: eval_renko_signals() returns R1-R8 signals
    # -----------------------------------------------------------------
    bricks = compute_renko_bricks(test_df)
    assert len(bricks) > 0
    r_rsi = compute_renko_rsi(bricks)
    r_signals = eval_renko_signals(bricks, None, len(bricks) - 1, r_rsi)
    assert "R1" in r_signals and "R8" in r_signals
    print(f"[PASS 11/14] eval_renko_signals() returned {len(r_signals)} Renko signals (R1-R8)")
    passed += 1

    # -----------------------------------------------------------------
    # Check 12: PE field is null in SignalsService output
    # -----------------------------------------------------------------
    from api.services.signals_service import SignalsService
    service = SignalsService()
    stock = service.score_single_df("TATAMOTORS", test_df)
    assert stock is not None
    assert stock.PE is None
    print(f"[PASS 12/14] PE field in SignalStock is null (PE: {stock.PE})")
    passed += 1

    # -----------------------------------------------------------------
    # Check 13: Zero 'apollo_core' references in core/
    # -----------------------------------------------------------------
    found_legacy_refs = []
    for py_file in glob.glob(os.path.join(PROJECT_ROOT, "core", "*.py")):
        with open(py_file, "r", encoding="utf-8") as f:
            content = f.read()
            if "apollo_core" in content:
                found_legacy_refs.append(os.path.basename(py_file))
    assert len(found_legacy_refs) == 0, f"Legacy apollo_core references found in: {found_legacy_refs}"
    print("[PASS 13/14] Zero legacy 'apollo_core' package references in core/")
    passed += 1

    # -----------------------------------------------------------------
    # Check 14: Full 49-field SignalStock serialization contract test
    # -----------------------------------------------------------------
    stock_dict = stock.model_dump(by_alias=True)
    required_keys = [
        "Symbol", "Date", "Apollo_Action", "Apollo_Score", "Pct_Change",
        "LayerSignal_Action", "LayerSignal_Score", "Exit_Pressure",
        "Open", "High", "Low", "Close", "Volume",
        "High52W", "Low52W", "RSI21", "RSI36", "RSI56",
        "ADX", "ATR_Pct", "20D_SMA", "50D_SMA", "200D_SMA",
        "PE", "Stochastic", "52W_Prox", "CMP", "Traded_Value",
        "Bucket", "LStage", "ELStatus", "Conviction",
        "Gates", "Renko", "MCap", "FQS", "Sparkline",
        "ThrowbackAlert", "ml_confidence", "SubScores", "GatesExplanations",
        "HistoricalL3Events", "isIPO", "ipoData"
    ]
    for k in required_keys:
        assert k in stock_dict, f"Missing field in serialized SignalStock: {k}"

    summary = service.compute_summary([stock])
    assert summary.total == 1

    print(f"[PASS 14/14] End-to-end contract test passed! All 49 fields serialized with exact TypeScript keys")
    passed += 1

    print("=" * 70)
    print(f"RESULT: ALL {passed}/{total} VERIFICATION CHECKS PASSED SUCCESSFULLY!")
    print("=" * 70)

if __name__ == "__main__":
    run_all_tests()
